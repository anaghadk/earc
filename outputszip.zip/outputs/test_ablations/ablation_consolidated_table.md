# EARC Component Ablation Study (Experiment 1) — Consolidated Report

## 1. Executive Summary & Experimental Setup
- **Retrieval**: Dense retrieval with `sentence-transformers/all-MiniLM-L6-v2`, FAISS `top_k=10`
- **Target Token Budget**: 300 tokens
- **Ablation Variants**:
  - **A1: Semantic-only**: $H(s) = \text{Sim}(q,s)$, no redundancy filter
  - **A2: Semantic + Evidence**: $H(s) = 0.7\text{Sim} + 0.3\text{Ev}$, no redundancy filter
  - **A3: Semantic + Redundancy**: $H(s) = \text{Sim}(q,s)$, with redundancy filter ($\tau=0.85$)
  - **A4: Evidence + Redundancy**: $H(s) = \text{Ev}(s)$, with redundancy filter ($\tau=0.85$)
  - **A5: Full EARC**: $H(s) = 0.7\text{Sim} + 0.3\text{Ev}$, with redundancy filter ($\tau=0.85$)

## 2. Consolidated Comparison Tables
### Provider: `OLLAMA`

| Dataset | Variant | EM (%) | F1 (%) | Tokens | Comp % | Comp Ratio | Latency (s) | Ev. Retention | Abs. ΔEM (A5 - Ax) | Rel. ΔEM (%) |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| NQ | A1: Semantic-only | 50.00% | 33.33% | 296.5 | 77.7% | 4.58x | 10.00s | 50.0% | -50.0 | -100.0% |
| NQ | A2: Semantic + Evidence | 0.00% | 0.00% | 298.5 | 77.5% | 4.56x | 2.96s | 50.0% | 0.0 | 0.0% |
| NQ | A3: Semantic + Redundancy | 50.00% | 33.33% | 296.5 | 77.7% | 4.58x | 3.02s | 50.0% | -50.0 | -100.0% |
| NQ | A4: Evidence + Redundancy | 0.00% | 0.00% | 298.5 | 77.5% | 4.56x | 3.13s | 0.0% | 0.0 | 0.0% |
| NQ | A5: Full EARC | 0.00% | 0.00% | 298.5 | 77.5% | 4.56x | 7.38s | N/A% | 0.0 | 0.0% |
