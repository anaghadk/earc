# EARC Component Ablation Study (Experiment 1) — Consolidated Report

## 1. Executive Summary & Experimental Setup
- **Retrieval**: Dense retrieval with `sentence-transformers/all-MiniLM-L6-v2`, FAISS `top_k=10`
- **Target Token Budget**: 300 tokens
- **Ablation Variants**:
  - **A1: Semantic-only**: $H(s) = \text{Sim}(q,s)$, no redundancy filter
  - **A2: Semantic + Evidence**: $H(s) = 0.7\text{Sim} + 0.3\text{Ev}$, no redundancy filter
  - **A3: Semantic + Redundancy**: $H(s) = \text{Sim}(q,s)$, with redundancy filter ($\tau=0.85$)
  - **A4: Evidence + Redundancy**: $H(s) = \text{Ev}(s)$, with redundancy filter ($\tau=0.85$)
  - **A5: Full EARC**: $H(s) = 0.7\text{Sim} + 0.3\text{Ev}$, with redundancy filter ($\tau=0.85$)

## 2. Consolidated Comparison Tables
### Provider: `MISTRAL`

| Dataset | Variant | EM (%) | F1 (%) | Tokens | Comp % | Comp Ratio | Latency (s) | Ev. Retention | Abs. ΔEM (A5 - Ax) | Rel. ΔEM (%) |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| NQ | A1: Semantic-only | 45.00% | 32.69% | 296.4 | 78.7% | 4.87x | 2.48s | 60.0% | -25.0 | -55.6% |
| NQ | A2: Semantic + Evidence | 50.00% | 35.72% | 295.9 | 78.7% | 4.88x | 1.49s | 60.0% | -30.0 | -60.0% |
| NQ | A3: Semantic + Redundancy | 50.00% | 38.54% | 296.6 | 78.7% | 4.87x | 1.51s | 60.0% | -30.0 | -60.0% |
| NQ | A4: Evidence + Redundancy | 50.00% | 38.91% | 296.1 | 78.7% | 4.88x | 1.34s | 45.0% | -30.0 | -60.0% |
| NQ | A5: Full EARC | 20.00% | 39.08% | 296.0 | 78.8% | 4.88x | 1.76s | N/A% | 0.0 | 0.0% |
| HOTPOT | A1: Semantic-only | 45.00% | 41.79% | 293.7 | 72.6% | 3.98x | 1.37s | 50.0% | -10.0 | -22.2% |
| HOTPOT | A2: Semantic + Evidence | 40.00% | 36.79% | 294.6 | 72.5% | 3.97x | 1.41s | 40.0% | -5.0 | -12.5% |
| HOTPOT | A3: Semantic + Redundancy | 45.00% | 41.79% | 293.6 | 72.6% | 3.98x | 1.22s | 50.0% | -10.0 | -22.2% |
| HOTPOT | A4: Evidence + Redundancy | 35.00% | 31.79% | 294.4 | 72.5% | 3.97x | 1.31s | 35.0% | 0.0 | 0.0% |
| HOTPOT | A5: Full EARC | 35.00% | 41.79% | 295.1 | 72.5% | 3.96x | 1.20s | N/A% | 0.0 | 0.0% |
| TRIVIA | A1: Semantic-only | 50.00% | 50.33% | 296.5 | 81.1% | 5.49x | 1.35s | 75.0% | -10.0 | -20.0% |
| TRIVIA | A2: Semantic + Evidence | 50.00% | 47.83% | 296.1 | 81.1% | 5.50x | 1.45s | 80.0% | -10.0 | -20.0% |
| TRIVIA | A3: Semantic + Redundancy | 50.00% | 50.33% | 296.3 | 81.1% | 5.50x | 1.72s | 75.0% | -10.0 | -20.0% |
| TRIVIA | A4: Evidence + Redundancy | 45.00% | 38.33% | 296.1 | 81.1% | 5.49x | 1.53s | 75.0% | -5.0 | -11.1% |
| TRIVIA | A5: Full EARC | 40.00% | 48.13% | 296.1 | 81.1% | 5.50x | 1.47s | N/A% | 0.0 | 0.0% |

### Provider: `OLLAMA`

| Dataset | Variant | EM (%) | F1 (%) | Tokens | Comp % | Comp Ratio | Latency (s) | Ev. Retention | Abs. ΔEM (A5 - Ax) | Rel. ΔEM (%) |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| NQ | A1: Semantic-only | 50.00% | 50.33% | 296.4 | 78.7% | 4.87x | 3.58s | 60.0% | -10.0 | -20.0% |
| NQ | A2: Semantic + Evidence | 40.00% | 40.00% | 295.9 | 78.7% | 4.88x | 2.98s | 60.0% | 0.0 | 0.0% |
| NQ | A3: Semantic + Redundancy | 50.00% | 50.33% | 296.6 | 78.7% | 4.87x | 2.94s | 60.0% | -10.0 | -20.0% |
| NQ | A4: Evidence + Redundancy | 35.00% | 35.00% | 296.1 | 78.7% | 4.88x | 2.95s | 45.0% | +5.0 | +14.3% |
| NQ | A5: Full EARC | 40.00% | 40.00% | 296.0 | 78.8% | 4.88x | 3.41s | N/A% | 0.0 | 0.0% |
| HOTPOT | A1: Semantic-only | 25.00% | 31.43% | 293.7 | 72.6% | 3.98x | 2.90s | 50.0% | 0.0 | 0.0% |
| HOTPOT | A2: Semantic + Evidence | 25.00% | 28.93% | 294.6 | 72.5% | 3.97x | 2.88s | 40.0% | 0.0 | 0.0% |
| HOTPOT | A3: Semantic + Redundancy | 25.00% | 31.43% | 293.6 | 72.6% | 3.98x | 2.86s | 50.0% | 0.0 | 0.0% |
| HOTPOT | A4: Evidence + Redundancy | 30.00% | 33.93% | 294.4 | 72.5% | 3.97x | 2.89s | 35.0% | -5.0 | -16.7% |
| HOTPOT | A5: Full EARC | 25.00% | 28.93% | 295.1 | 72.5% | 3.96x | 2.86s | N/A% | 0.0 | 0.0% |
| TRIVIA | A1: Semantic-only | 60.00% | 62.00% | 296.5 | 81.1% | 5.49x | 3.04s | 75.0% | -40.0 | -66.7% |
| TRIVIA | A2: Semantic + Evidence | 45.00% | 37.00% | 296.1 | 81.1% | 5.50x | 2.97s | 80.0% | -25.0 | -55.6% |
| TRIVIA | A3: Semantic + Redundancy | 60.00% | 62.00% | 296.3 | 81.1% | 5.50x | 2.96s | 75.0% | -40.0 | -66.7% |
| TRIVIA | A4: Evidence + Redundancy | 45.00% | 36.24% | 296.1 | 81.1% | 5.49x | 2.99s | 75.0% | -25.0 | -55.6% |
| TRIVIA | A5: Full EARC | 20.00% | 32.91% | 296.1 | 81.1% | 5.50x | 2.83s | N/A% | 0.0 | 0.0% |
