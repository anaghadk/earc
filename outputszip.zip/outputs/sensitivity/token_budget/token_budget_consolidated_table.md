# Experiment 3 — Token-Budget Sensitivity Analysis Report

## 1. Executive Summary & Experimental Controls
This experiment evaluates how EARC behaves under varying context token budgets $T \in \{100, 150, 200, 300, 400, 500, 750\}$.
- **Fixed Parameters**: $\alpha = 0.7$, $\beta = 0.3$, redundancy threshold $\tau = 0.85$, top-$k=10$ dense retrieval (all-MiniLM-L6-v2), temperature 0.0, identical random seed (42).
- **Compared Baselines**: Standard RAG (uncompressed context) and LLMLingua-2 (budget=300 tokens).

## 2. Quantitative Results Table Across All Budgets
### Provider: `MISTRAL`

| Dataset | Method / Budget | Exact Match (%) | Token F1 (%) | Avg Tokens | Comp % | Comp Ratio | Latency (s) | Ev. Retention (%) | Notes |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| HOTPOT | **Standard RAG** | 30.00% | 39.70% | 1246.2 | 0.0% | 1.00x | 0.93s | 100.0% | Uncompressed full context |
| HOTPOT | **LLMLingua-2 (300t)** | 15.00% | 31.21% | 297.2 | 76.1% | 4.19x | 1.21s | N/A | Token-level pruning |
| HOTPOT | EARC (100 tokens) | 40.00% | 37.62% | 96.4 | 91.0% | 12.14x | 2.25s | 90.0% | EARC 100t |
| HOTPOT | EARC (150 tokens) | 40.00% | 37.69% | 146.7 | 86.3% | 7.97x | 1.84s | 90.0% | EARC 150t |
| HOTPOT | EARC (200 tokens) | 40.00% | 36.79% | 195.9 | 81.7% | 5.97x | 1.79s | 90.0% | EARC 200t |
| HOTPOT | EARC (300 tokens) | 40.00% | 36.79% | 295.4 | 72.4% | 3.96x | 1.54s | 40.0% | **Production Target (300t)** |
| HOTPOT | EARC (400 tokens) | 45.00% | 39.29% | 391.9 | 63.5% | 2.98x | 1.90s | 100.0% | EARC 400t |
| HOTPOT | EARC (500 tokens) | 45.00% | 40.00% | 487.7 | 55.1% | 2.39x | 1.80s | 100.0% | EARC 500t |
| HOTPOT | EARC (750 tokens) | 45.00% | 43.69% | 721.0 | 34.6% | 1.62x | 2.18s | 100.0% | EARC 750t |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| NQ | **Standard RAG** | 20.00% | 44.17% | 1511.4 | 0.0% | 1.00x | 1.49s | 100.0% | Uncompressed full context |
| NQ | **LLMLingua-2 (300t)** | 30.00% | 41.19% | 304.0 | 79.9% | 4.97x | 1.37s | N/A | Token-level pruning |
| NQ | EARC (100 tokens) | 50.00% | 41.66% | 97.0 | 93.1% | 14.87x | 2.97s | 60.0% | EARC 100t |
| NQ | EARC (150 tokens) | 45.00% | 41.19% | 145.8 | 89.5% | 9.90x | 1.94s | 65.0% | EARC 150t |
| NQ | EARC (200 tokens) | 45.00% | 39.29% | 196.3 | 85.9% | 7.36x | 1.93s | 60.0% | EARC 200t |
| NQ | EARC (300 tokens) | 50.00% | 35.72% | 296.0 | 78.7% | 4.88x | 1.66s | 65.0% | **Production Target (300t)** |
| NQ | EARC (400 tokens) | 60.00% | 45.51% | 394.3 | 71.7% | 3.66x | 1.87s | 85.0% | EARC 400t |
| NQ | EARC (500 tokens) | 60.00% | 45.51% | 493.6 | 64.6% | 2.93x | 1.79s | 90.0% | EARC 500t |
| NQ | EARC (750 tokens) | 60.00% | 47.45% | 742.2 | 46.7% | 1.95x | 1.85s | 95.0% | EARC 750t |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| TRIVIA | **Standard RAG** | 45.00% | 52.83% | 1697.8 | 0.0% | 1.00x | 1.09s | 100.0% | Uncompressed full context |
| TRIVIA | **LLMLingua-2 (300t)** | 30.00% | 40.33% | 316.1 | 81.4% | 5.37x | 0.95s | N/A | Token-level pruning |
| TRIVIA | EARC (100 tokens) | 50.00% | 46.17% | 97.2 | 93.8% | 16.76x | 1.80s | 60.0% | EARC 100t |
| TRIVIA | EARC (150 tokens) | 50.00% | 47.83% | 146.8 | 90.7% | 11.08x | 1.68s | 60.0% | EARC 150t |
| TRIVIA | EARC (200 tokens) | 40.00% | 37.83% | 196.8 | 87.5% | 8.27x | 1.70s | 65.0% | EARC 200t |
| TRIVIA | EARC (300 tokens) | 55.00% | 48.01% | 296.1 | 81.1% | 5.50x | 1.71s | 80.0% | **Production Target (300t)** |
| TRIVIA | EARC (400 tokens) | 50.00% | 43.01% | 395.4 | 74.8% | 4.12x | 1.87s | 85.0% | EARC 400t |
| TRIVIA | EARC (500 tokens) | 55.00% | 46.39% | 492.9 | 68.6% | 3.30x | 1.72s | 85.0% | EARC 500t |
| TRIVIA | EARC (750 tokens) | 50.00% | 47.83% | 741.9 | 52.7% | 2.19x | 1.82s | 95.0% | EARC 750t |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
