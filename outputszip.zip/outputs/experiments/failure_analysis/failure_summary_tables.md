# Systematic Failure Analysis of EARC — Comprehensive Summary

## 1. Executive Summary & Failure Taxonomy
Every incorrect EARC prediction was systematically attributed to one of four mutually exclusive primary root causes:
- **F1. Retrieval Failure**: The required factual evidence was absent from the top-10 retrieved candidate documents.
- **F2. Compression / Evidence-Selection Failure**: The required evidence existed in retrieved candidates, but EARC removed it during ranking or budget truncation.
- **F3. LLM Generation / Reasoning Failure**: The required evidence was preserved in the compressed prompt, but the LLM hallucinated, missed it, or made a synthesis error.
- **F4. Evaluation / Extraction Failure**: The LLM produced the correct answer semantically, but the extraction/normalization regex marked EM=0.

## 2. Quantitative Failure Percentages

### A. Breakdown by Dataset & Model
| Model | Dataset | Total Queries | Errors | F1: Retrieval (%) | F2: Compression (%) | F3: Generation (%) | F4: Evaluation (%) |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| Ministral-8B | **HOTPOT** | 1000 | 633 | **55.9%** (354) | **14.8%** (94) | **16.9%** (107) | **12.3%** (78) |
| Ministral-8B | **NQ** | 1000 | 767 | **54.1%** (415) | **18.4%** (141) | **14.0%** (107) | **13.6%** (104) |
| Ministral-8B | **TRIVIA** | 1000 | 477 | **31.7%** (151) | **18.0%** (86) | **19.7%** (94) | **30.6%** (146) |
| Llama 3.2 | **HOTPOT** | 1000 | 716 | **53.4%** (382) | **13.8%** (99) | **27.5%** (197) | **5.3%** (38) |
| Llama 3.2 | **NQ** | 1000 | 787 | **53.6%** (422) | **19.3%** (152) | **20.5%** (161) | **6.6%** (52) |
| Llama 3.2 | **TRIVIA** | 1000 | 554 | **30.5%** (169) | **20.2%** (112) | **30.1%** (167) | **19.1%** (106) |

### B. Aggregated by Dataset (Across Both Models)
| Dataset | Total Errors | F1: Retrieval (%) | F2: Compression (%) | F3: Generation (%) | F4: Evaluation (%) | Primary Bottleneck |
| :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| **HOTPOT** | 1349 | 54.6% | 14.3% | 22.5% | 8.6% | **Retrieval (all-MiniLM-L6-v2)** |
| **NQ** | 1554 | 53.9% | 18.9% | 17.2% | 10.0% | **Retrieval (all-MiniLM-L6-v2)** |
| **TRIVIA** | 1031 | 31.0% | 19.2% | 25.3% | 24.4% | **Retrieval (all-MiniLM-L6-v2)** |

### C. Aggregated by Model (Across All Datasets)
| Model | Total Errors | F1: Retrieval (%) | F2: Compression (%) | F3: Generation (%) | F4: Evaluation (%) | Model Characteristic |
| :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| **Ministral-8B** | 1877 | 49.0% | 17.1% | 16.4% | 17.5% | Higher reasoning capacity, lower F3 failure |
| **Llama 3.2** | 2057 | 47.3% | 17.6% | 25.5% | 9.5% | Smaller 3B capacity, elevated F3 failure |
