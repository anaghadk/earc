# Representative Failure Examples — EARC Error Diagnostics

This document details 5 representative cases for each of the four systematic failure categories.

## F1. Retrieval Failure (Required evidence absent from retrieved top-10)

### Example 1 (ID: `hotpot_q0003648`, Dataset: `HOTPOT`, Model: `Ministral-8B`)
- **Question**: What is the birth date of this English scientist, whose laboratory burner design was later perfected by Peter Desaga into the Bunsen burner?
- **Gold Answer**: `['22 September 1791']`
- **Generated Raw Answer**: `Final answer: Michael Faraday`
- **Normalized Prediction**: `Michael Faraday`
- **Primary Root Cause**: `F1_retrieval_failure`
- **Diagnostic Explanation**: The required factual answer was never retrieved into the top-10 candidate passages.
- **Retrieved Passages**: Peter Desaga, Robert Bunsen, Robert Bunsen, Robert Bunsen, Bunsen burner

#### Ground-Truth Supporting Facts:
> 🔍 Peter Desaga was a German instrument maker at the University of Heidelberg who worked with Robert Wilhelm Bunsen.
> 🔍  In 1855, Desaga perfected an earlier design of the laboratory burner by Michael Faraday into the Bunsen burner.
> 🔍 Michael Faraday FRS ( ; 22 September 1791 – 25 August 1867) was an English scientist who contributed to the study of electromagnetism and electrochemistry.

#### Selected EARC Sentences:
- ✅ Peter Desaga: In 1855, Desaga perfected an earlier design of the laboratory burner by Michael Faraday into the Bunsen burner.
- ✅ Robert Bunsen: For this work, Bunsen and his laboratory assistant, Peter Desaga, had perfected a special gas burner by 1855, which was influenced by earlier models.
- ✅ 17th century: * Galileo Galilei, Italian natural philosopher (1564–1642)
* Pierre Gassendi, (1592–1655), French philosopher, priest, scientist, astronomer/astrologer, and mathematician
* William Harvey, medical doctor (1578–1657)
* Thomas Hobbes, English philosopher and mathematician (1588–1679)
* Christiaan Huygens, Dutch mathematician, physicist and astronomer (1629–1695)
* Johannes Kepler, German astronomer (1571–1630)
* Antonie van Leeuwenhoek, Dutch scientist and the first person to use a microscope to view bacteria (16

#### Removed Candidate Sentences (Pruned by EARC):
- ❌ Robert Bunsen: With his laboratory assistant, Peter Desaga, he developed the Bunsen burner, an improvement on the laboratory burners then in use.
- ❌ Peter Desaga: The Bunsen burner was essential to the invention of the spectroscope by Robert Wilhelm Bunsen and Gustav Robert Georg Kirchhoff.
- ❌ Robert Bunsen: The newer design of Bunsen and Desaga, which provided a very hot and clean flame, is now called simply the "Bunsen burner", a common laboratory equipment.

---

### Example 2 (ID: `hotpot_q0007314`, Dataset: `HOTPOT`, Model: `Ministral-8B`)
- **Question**: Who was the leader of the secret police of Nazi Germany?
- **Gold Answer**: `['Eugen Schwitzgebel']`
- **Generated Raw Answer**: `Final answer: Heinrich Müller`
- **Normalized Prediction**: `Heinrich Müller`
- **Primary Root Cause**: `F1_retrieval_failure`
- **Diagnostic Explanation**: The required factual answer was never retrieved into the top-10 candidate passages.
- **Retrieved Passages**: Gestapo, Gestapo, Gestapo, Heinrich Müller (Gestapo), Gestapo

#### Ground-Truth Supporting Facts:
> 🔍 Eugen Schwitzgebel (1900 – 31 October 1944, in Aarhus) was a German officer, a SS Sturmbannführer and Gestapo leader in Aarhus during the Second World War.
> 🔍 The Gestapo (] ), abbreviation of Geheime Staatspolizei, or the Secret State Police, was the official secret police of Nazi Germany and German-occupied Europe.

#### Selected EARC Sentences:
- ✅ Heinrich Müller (Gestapo): Heinrich Müller (28 April 1900; date of death unknown, but evidence points to May 1945) was a German police official under both the Weimar Republic and Nazi Germany.
- ✅ Gestapo: *Klaus Barbie (SiPo-SD Lyon)
*Werner Best (SiPo-SD Copenhagen)
*Karl Bömelburg (Head of Gestapo, Southern France)
*Theodor Dannecker (SiPo-SD Paris)
*Rudolf Diels (Chief 1933–1934)
*Adolf Eichmann (RSHA Berlin)
*Hans Ehlich
*Gerhard Flesch
*Hermann Göring (Founder of the Gestapo)
*Viktor Harnischfeger (Düsseldorf Gestapo Criminal Commissar)
*Reinhard Heydrich (SD, SiPo, Gestapo Chief 1934–1939, RSHA Chief 1939–1942)
*Hei
- ✅ Hans Oster: Hans Paul Oster (9 August 1887 – 9 April 1945) was a general in the Wehrmacht of Nazi Germany who was also a leading figure of the German resistance from 1938 to 1943.

#### Removed Candidate Sentences (Pruned by EARC):
- ❌ Gestapo: Beginning on 20 April 1934, it was under the administration of SS national leader Heinrich Himmler, who in 1936 was appointed Chief of German Police (Chef der Deutschen Polizei) by Hitler.
- ❌ Gestapo: Organization

On January 1933, Hermann Göring, Hitler's minister without portfolio, was appointed the head of the Prussian Police and began filling the political and intelligence units of the Prussian Secret Police with Nazi Party members.
- ❌ Gestapo: *Heinrich Himmler (Reichsführer-SS)
*Ernst Kaltenbrunner (RSHA Chief 1943–1945)
*Herbert Kappler (SD Chief Rome)
*Helmut Knochen (Paris)
*Kurt Kohl (SiPo-SD Lille, France)
*Kurt Lischka (Paris)
*Ernst Misselwitz (Hauptscharführer SiPo-SD Paris)
*Violette Morris
*Heinrich Müller (Chief 1939–1945)
*Karl Oberg (Paris)
*Pierre Paoli (Head of Gestapo, Central France)
*Oswald Poche (Chief of Frankfurt Lindenstrasse station)
*Henry Oliver Rinnan
*Karl Eberhard Schöngarth
*Max Wielen

---

### Example 3 (ID: `hotpot_q0013825`, Dataset: `HOTPOT`, Model: `Ministral-8B`)
- **Question**: What New York State county are soul/funk band Mandril based in?
- **Gold Answer**: `['Kings County']`
- **Generated Raw Answer**: `Final answer: Brooklyn`
- **Normalized Prediction**: `Brooklyn`
- **Primary Root Cause**: `F1_retrieval_failure`
- **Diagnostic Explanation**: The required factual answer was never retrieved into the top-10 candidate passages.
- **Retrieved Passages**: Mandrilland, The Drums, Manoil Manufacturing Co., Soul music, Kat Wright and the Indomitable Soul Band

#### Ground-Truth Supporting Facts:
> 🔍 Mandrilland is the fifth album by Brooklyn-based soul/funk band Mandrill.
> 🔍  Since 1896, Brooklyn has had the same boundaries as Kings County, the most populous county in the U.S. state of New York and the second-most densely populated county in the United States, after the county of New York (which is coextensive with the borough of Manhattan).

#### Selected EARC Sentences:
- ✅ Mandrilland is the fifth album by Brooklyn-based soul/funk band Mandrill. .
- ✅ Kat Wright and the Indomitable Soul Band is an eight piece, blue-eyed soul band based in Burlington, Vermont, formed in 2010.
- ✅ The Drums are an American indie pop band from New York City.

#### Removed Candidate Sentences (Pruned by EARC):
- ❌ Soul music: Psychedelic soul 

Psychedelic soul, sometimes known as "black rock", was a blend of psychedelic rock and soul music in the late 1960s, which paved the way for the mainstream emergence of funk music a few years later.
- ❌ New Jersey: Some of the most popular ska bands, such as Catch 22 and Streetlight Manifesto, come from East Brunswick.
- ❌ New Jersey: The Bouncing Souls original four members grew up in Basking Ridge and formed in New Brunswick in the late 1980s.

---

### Example 4 (ID: `hotpot_q0001041`, Dataset: `HOTPOT`, Model: `Ministral-8B`)
- **Question**: What disorder the man whose protege starred in Where Danger Lives have?
- **Gold Answer**: `['OCD']`
- **Generated Raw Answer**: `Final answer: Howard Hughes`
- **Normalized Prediction**: `Howard Hughes`
- **Primary Root Cause**: `F1_retrieval_failure`
- **Diagnostic Explanation**: The required factual answer was never retrieved into the top-10 candidate passages.
- **Retrieved Passages**: Where Danger Lives, The Prisoner, The Prisoner, The Mousetrap, Danger Mouse (1981 TV series)

#### Ground-Truth Supporting Facts:
> 🔍 Where Danger Lives is a 1950 film noir thriller directed by John Farrow and starring Robert Mitchum, Faith Domergue and Claude Rains.
> 🔍  At the time, Domergue was the latest of Howard Hughes' proteges.
> 🔍  Later in life, he became known for his eccentric behavior and reclusive lifestyle—oddities that were caused in part by a worsening obsessive–compulsive disorder (OCD) and chronic pain from a plane crash.

#### Selected EARC Sentences:
- ✅ Where Danger Lives is a 1950 film noir thriller directed by John Farrow and starring Robert Mitchum, Faith Domergue and Claude Rains.
- ✅ Science fiction film: Examples of such a storyline can be found in the movies Dr. Strangelove (1964), Planet of the Apes (1968), A Boy and His Dog (1975), Mad Max (1979), City of Ember (2008), The Book of Eli (2010), and Oblivion (2013).
- ✅ Danger Mouse (1981 TV series): Penfold is naturally leery of the professor, as he often winds up on the wrong side of his experiments.

#### Removed Candidate Sentences (Pruned by EARC):
- ❌ Where Danger Lives: At the time, Domergue was the latest of Howard Hughes' proteges.
- ❌ Science fiction film: This topic has been treated in such films as The Andromeda Strain (1971), The Omega Man (1971), 12 Monkeys (1995), 28 Weeks Later (2007),  I am Legend (2007) and the  Resident Evil series.
- ❌ Danger Mouse (1981 TV series): Victor and Hugo (1991): Appeared as himself in the series.

---

### Example 5 (ID: `hotpot_q0000976`, Dataset: `HOTPOT`, Model: `Ministral-8B`)
- **Question**: When was the director of King of the Dancehall born?
- **Gold Answer**: `['October 8, 1980']`
- **Generated Raw Answer**: `Final answer: November 15, 1972`
- **Normalized Prediction**: `November 15, 1972`
- **Primary Root Cause**: `F1_retrieval_failure`
- **Diagnostic Explanation**: The required factual answer was never retrieved into the top-10 candidate passages.
- **Retrieved Passages**: King of the Dancehall (film), Jamie King, The King and I, The King and I, Yul Brynner

#### Ground-Truth Supporting Facts:
> 🔍 King of the Dancehall is a 2016 American drama film directed by Nick Cannon.
> 🔍 Nicholas Scott "Nick" Cannon (born October 8, 1980) is an American rapper, actor, comedian, director, screenwriter, film producer, entrepreneur, record producer, radio and television personality.

#### Selected EARC Sentences:
- ✅ King of the Dancehall (film): It was screened in the Special Presentations section at the 2016 Toronto International Film Festival.
- ✅ Jamie King (born 1972) is an American creative director, choreographer, and producer whose work directing concert tours for pop stars has grossed over two billion dollars.
- ✅ The King and I: 01&id
DO0bAAAAIBAJ&sjidp1IEAAAAIBAJ&pg
4095,6633 "Brynner Bows Out as 'King of Slam'"], The Dispatch, July 1, 1985, p. 2.

#### Removed Candidate Sentences (Pruned by EARC):
- ❌ King of the Dancehall (film): King of the Dancehall is a 2016 American drama film directed by Nick Cannon.
- ❌ The King and I: From August 1989 to March 1990, Rudolf Nureyev played the King in a North American tour opposite Liz Robertson, with Kermoyan as the Kralahome, directed by Arthur Storch and with the original Robbins choreography.
- ❌ Yul Brynner: The King and I (1977) (Broadway, London and US national tour)
*

---

## F2. Compression / Evidence-Selection Failure (Evidence in candidates but pruned by EARC)

### Example 1 (ID: `hotpot_q0000819`, Dataset: `HOTPOT`, Model: `Ministral-8B`)
- **Question**: Where is a place that has both Lano Estacado and Buda Limestone geological formations?
- **Gold Answer**: `['High Plains']`
- **Generated Raw Answer**: `Final answer: Andes`
- **Normalized Prediction**: `Andes`
- **Primary Root Cause**: `F2_compression_failure`
- **Diagnostic Explanation**: The required evidence was present in retrieved candidates, but EARC pruned it from the compressed context.
- **Retrieved Passages**: Buda Limestone, Patagonia, Patagonia, Easter Island, Easter Island

#### Ground-Truth Supporting Facts:
> 🔍 The Buda Limestone is a geological formation in the High Plains and Trans-Pecos regions of West Texas whose strata date back to the Late Cretaceous.
> 🔍  The southern region of the Western High Plains ecology region contains the geological formation known as Llano Estacado which can be seen from a short distance or from on satellite maps.

#### Selected EARC Sentences:
- ✅ Andes: near Otavalo
File:Historic Center of Quito - World Heritage Site by UNESCO - Photo 186.JPG|Pichincha Volcano, an active stratovolcano in the Ecuadorian Andes photographed from the Historic Center of Quito
File:Andes Mountains South America Photograph 022.JPG|Imbabura Volcano, an inactive stratovolcano

Peru

* Alpamayo, 5947 m
* Artesonraju, 6025 m
* Carnicero, 5960 m
* Chumpi, 6106 m
* Coropuna, 6377 m
* El Misti, 5822 m
* El Toro, 5830 m
* Huandoy, 6395 m
* Huascarán, 6768 m
* Jirishanca, 6094 m
* Pumasillu, 5991 m
* Rasaq, 6040 m
* Runtuy, 5870 m
* Sarapu, 6127 m
* Salcantay, 6271 m
* Seria Norte, 5860 m
* Siula Grande, 6344 m
* Waytapallana, 5557 m
* Yerupaja, 6635 m
*
- ✅ Minas Gerais: Recent advances in env
- ✅ Patagonia: It generally separates

#### Removed Candidate Sentences (Pruned by EARC):
- ❌ Buda Limestone: The Buda Limestone is a geological formation in the High Plains and Trans-Pecos regions of West Texas whose strata date back to the Late Cretaceous.
- ❌ Buda Limestone: Pterosaur remains are among the fossils that have been recovered from the formation.
- ❌ Minas Gerais: Around Lagoa Santa and Sete Lagoas a typical Karst topography with caves and lakes is found.

---

### Example 2 (ID: `hotpot_q0011763`, Dataset: `HOTPOT`, Model: `Ministral-8B`)
- **Question**: Who has won more grand slam double titles, Andrea Hlaváčková or Tony Roche?
- **Gold Answer**: `['Anthony Dalton Roche']`
- **Generated Raw Answer**: `Final answer: Tony Roche`
- **Normalized Prediction**: `Tony Roche`
- **Primary Root Cause**: `F2_compression_failure`
- **Diagnostic Explanation**: The required evidence was present in retrieved candidates, but EARC pruned it from the compressed context.
- **Retrieved Passages**: Andrea Hlaváčková, Andrea Hlaváčková, Jana Hlaváčková, Andre Agassi, 2015 Australian Open

#### Ground-Truth Supporting Facts:
> 🔍  She has won two Grand Slam doubles titles, the 2011 French Open and the 2013 US Open, both times partnered with Lucie Hradecká.
> 🔍 Anthony Dalton Roche, AO MBE (born 17 May 1945) is a former professional Australian tennis player, native of Tarcutta.
> 🔍  He won one Grand Slam singles title and thirteen Grand Slam doubles titles, and was ranked as high as World No. 2 by Lance Tingay of "The Daily Telegraph" in 1969.

#### Selected EARC Sentences:
- ✅ Andrea Hlaváčková: She has won two Grand Slam doubles titles, the 2011 French Open and the 2013 US Open, both times partnered with Lucie Hradecká.
- ✅ Tony Roche: He won one Grand Slam singles title and thirteen Grand Slam doubles titles, and was ranked as high as World No. 2 by Lance Tingay of "The Daily Telegraph" in 1969.
- ✅ 2010 French Open: Juniors

Boys' singles

 Agustín Velotti defeated  Andrea Collarini, 6–4, 7–5

Girls' singles

 Elina Svitolina defeated  Ons Jabeur, 6–2, 7–5

#### Removed Candidate Sentences (Pruned by EARC):
- ❌ Andrea Hlaváčková: Her highest singles ranking is world No. 58, which she reached in September 2012, and her highest doubles ranking is No. 3, reached on 22 October 2012.
- ❌ Andrea Hlaváčková: In her career, Hlaváčková has won 22 WTA doubles titles, as well as 19 ITF doubles and eight ITF singles titles.
- ❌ Tony Roche: He also coached multi-Grand Slam winning World No. 1s, Ivan Lendl, Patrick Rafter, Roger Federer, Lleyton Hewitt and former World No. 4, Jelena Dokic.

---

### Example 3 (ID: `hotpot_q0011270`, Dataset: `HOTPOT`, Model: `Ministral-8B`)
- **Question**: Which contributor to Izzard won the 2016 Hugo Award for Best Fan Artist?
- **Gold Answer**: `['Steve Stiles']`
- **Generated Raw Answer**: `Final answer: None (no contributor to *Izzard* won the 2016 Hugo Award for Best Fan Artist in the provided evidence).`
- **Normalized Prediction**: `None (no contributor to *Izzard* won the 2016 Hugo Award for Best Fan Artist in the provided evidence)`
- **Primary Root Cause**: `F2_compression_failure`
- **Diagnostic Explanation**: The required evidence was present in retrieved candidates, but EARC pruned it from the compressed context.
- **Retrieved Passages**: Hugo Award for Best Fan Artist, Izzard (fanzine), Frank Wu (artist), Hugo Award for Best Fan Artist, Hyperpilosity

#### Ground-Truth Supporting Facts:
> 🔍  Contributors included Terry Carr, Steve Stiles, Greg Benford, Ted White, Greg Pickersgill, Avedon Carol, Dave Langford, Stu Shiffman, Taral Wayne, Ray Nelson and Alexis Gilliland.
> 🔍  He won the 2016 Hugo Award for Best Fan Artist.

#### Selected EARC Sentences:
- ✅ Hugo Award for Best Fan Artist: To date, Retro Hugo awards have been awarded for 1939, 1941, 1946, 1951, and 1954, although the 1939, 1941, and 1954 Retro Hugos received insufficient nominations for the Fan Artist Hugo to make the ballot.
- ✅ Frank Wu (artist): He won the Hugo Award for Best Fan Artist in 2004, 2006, 2007 and 2009; he was previously nominated in 2002 and 2003.
- ✅ Izzard (fanzine): It was nominated for the Hugo Award in 1984.

#### Removed Candidate Sentences (Pruned by EARC):
- ❌ Hugo Award for Best Fan Artist: Beginning in 1996, Retrospective Hugo Awards, or "Retro Hugos", have been available to be awarded for years 50, 75, or 100 years prior in which no awards were given.
- ❌ Hugo Award for Best Fan Artist: rd for professional artists is also given.
- ❌ Hugo Award for Best Fan Artist: The Hugo Award for Best Fan Artist is given each year for artists of works related to science fiction or fantasy which appeared in low- or non-paying publications such as semiprozines or fanzines.

---

### Example 4 (ID: `hotpot_q0011850`, Dataset: `HOTPOT`, Model: `Ministral-8B`)
- **Question**: What is the population of the satellite community to New Sweden ?
- **Gold Answer**: `['253']`
- **Generated Raw Answer**: `Final answer: **No relevant data about the population of the satellite community to New Sweden is provided in the evidence.**`
- **Normalized Prediction**: `**No relevant data about the population of the satellite community to New Sweden is provided in the evidence`
- **Primary Root Cause**: `F2_compression_failure`
- **Diagnostic Explanation**: The required evidence was present in retrieved candidates, but EARC pruned it from the compressed context.
- **Retrieved Passages**: Sweden, Sweden, Sweden, Sweden, Sweden

#### Ground-Truth Supporting Facts:
> 🔍  This eventually resulted, for example, in the founding of the northern Maine immigrant community of New Sweden and its satellite Stockholm, Maine.
> 🔍 Stockholm is a town in Aroostook County, Maine, United States.
> 🔍  The population was 253 at the 2010 census.

#### Selected EARC Sentences:
- ✅ Sweden: Thus, with the total population in 2011 being 9,482,855, roughly 15% of the population was born abroad, 4.5% of the population was born in Sweden to two parents born abroad, and another 7% was born in Sweden to one parent born abroad.
- ✅ Helsingborg: There is no formal metropolitan area, but the municipality of Helsingborg City and its neighbouring five municipalities (within Scania) had in spring of 2013 a population of 269.489 inhabitants at an area of 1.353 km2 , a population density of 200 people/km.
- ✅ Denmark: ea including Greenland and the Faroe Islands is 2210579 km2 , and a population of 5.75 million (as of 2017 ).

#### Removed Candidate Sentences (Pruned by EARC):
- ❌ Sweden: Together with Greater Copenhagen, the entire population around the Öresund counts close to 3 million at a land area of less than 6000 km2.
- ❌ Sweden: According to Eurostat, in 2010, there were 1.33 million foreign-born residents in Sweden, corresponding to 14.3% of the total population.
- ❌ Sweden: An other area with notably higher population density compared to the general Swedish, is the

---

### Example 5 (ID: `hotpot_q0002614`, Dataset: `HOTPOT`, Model: `Ministral-8B`)
- **Question**: Which Shakespeare play did the actress cast in Rogue One appear in for the Oxford University Dramatic Society?
- **Gold Answer**: `['The Comedy of Errors']`
- **Generated Raw Answer**: `Final answer: *As You Like It* (Oxford University Dramatic Society equivalent role: **RSC**)`
- **Normalized Prediction**: `*As You Like It* (Oxford University Dramatic Society equivalent role: **RSC**)`
- **Primary Root Cause**: `F2_compression_failure`
- **Diagnostic Explanation**: The required evidence was present in retrieved candidates, but EARC pruned it from the compressed context.
- **Retrieved Passages**: Shakespeare in Love, Shakespeare in Love, Twelfth Night, Twelfth Night, Shakespeare in Love

#### Ground-Truth Supporting Facts:
> 🔍  The cast includes Felicity Jones, Diego Luna, Riz Ahmed, Ben Mendelsohn, Donnie Yen, Mads Mikkelsen, Alan Tudyk, Jiang Wen and Forest Whitaker.
> 🔍  She took time off from acting to attend university at Wadham College, Oxford where she performed in Shakespeare's "The Comedy of Errors" for the Oxford University Dramatic Society, and has worked steadily since graduating in 2006.

#### Selected EARC Sentences:
- ✅ Rogue One Rogue One: A Star Wars Story, or simply Rogue One, is a 2016 American epic space opera film directed by Gareth Edwards.
- ✅ Shakespeare in Love: Cast

* Gwyneth Paltrow as Viola de Lesseps
* Joseph Fiennes as William Shakespeare
* Geoffrey Rush as Philip Henslowe
* Colin Firth as Lord Wessex
* Ben Affleck as Ned Alleyn
* Judi Dench as Elizabeth I of England
* Simon Callow as Edmund Tilney
* Jim Carter as Ralph Bashford
* Martin Clunes as Richard Burbage
* Antony Sher as
- ✅ David Tennant: Tennant contributed to several audio dramatisations of Shakespeare for the Arkangel Shakespeare series (1998).

#### Removed Candidate Sentences (Pruned by EARC):
- ❌ Shakespeare in Love: The Queen also tells Wessex, who followed Viola to the theatre, that Romeo and Juliet has won the bet for Shakespeare, and has Kent deliver his £50 with instructions to write something "a little more cheerful next time, for Twelfth Night".
- ❌ David Tennant: His first Shakespearean role for the RSC was in As You Like It (1996); having auditioned for the role of Orlando, the romantic lead, he was instead cast as the jester Touchstone, which he played in his natural Scottish accent.
- ❌ Shakespeare in Love: Viola de Lesseps, the daughter of a wealthy merchant, who has seen Shakespeare's plays at court, disguises herself as "Thomas Kent" to audition, then runs away.

---

## F3. LLM Generation / Reasoning Failure (Evidence preserved in context, but LLM erred)

### Example 1 (ID: `hotpot_q0009012`, Dataset: `HOTPOT`, Model: `Ministral-8B`)
- **Question**: what mutiny in India was thwarted by MI5(b) during World War I?
- **Gold Answer**: `['The February mutiny']`
- **Generated Raw Answer**: `Final answer: Hindu–German Mutiny`
- **Normalized Prediction**: `Hindu–German Mutiny`
- **Primary Root Cause**: `F3_generation_failure`
- **Diagnostic Explanation**: The required evidence was present in the compressed prompt, but the LLM hallucinated, missed it, or made a reasoning error.
- **Retrieved Passages**: Hindu–German Conspiracy, MI5(g), Ghadar Mutiny, Mutiny, Indian independence movement

#### Ground-Truth Supporting Facts:
> 🔍  Another subsection, the MI5(b), was formed in January 1917 to deal specifically with Indians and "other oriental races".
> 🔍  The February mutiny was ultimately thwarted when British intelligence infiltrated the Ghadarite movement and arrested key figures.

#### Selected EARC Sentences:
- ✅ Mutiny: After World War II

* Post–World War II demobilization strikes occurred within Allied military forces stationed across the Middle East, India and South-East Asia in the months and years following World War II.
- ✅ ] and was contained only with the rebels' defeat in Gwalior on 20 June 1858.[10] On 1 November 1858, the British granted amnesty to all rebels not involved in murder, though they did not declare the hostilities formally to have ended until 8 July 1859.
- ✅ Ghadar Mutiny: It was the most prominent amongst a number of plans of the much larger Hindu–German Mutiny, formulated between 1914 and 1917 to initiate a Pan-Indian rebellion against the British Raj during World War I.

#### Removed Candidate Sentences (Pruned by EARC):
- ❌ Mutiny: The Royal Indian Navy Mutiny encompasses a total strike and subsequent mutiny by the Indian sailors of the Royal Indian Navy on board ship and shore establishments  at Bombay (Mumbai) harbour on 18 February 1946.
- ❌ The rebellion is known by many names, including the Sepoy Mutiny, the Indian Mutiny, the Great Rebellion, the Revolt of 1857, the Indian Insurrection, and India's First War of Independence.[e][11]
- ❌ MI5(g): The MI5 itself, working under Vernon Kell, had a number of India experts at the beginning of the war.

---

### Example 2 (ID: `hotpot_q0004572`, Dataset: `HOTPOT`, Model: `Ministral-8B`)
- **Question**: Are Arshile Gorky and Eve Beglarian both painters?
- **Gold Answer**: `['no']`
- **Generated Raw Answer**: `Final answer: Arshile Gorky is a painter; Eve Beglarian is a composer.`
- **Normalized Prediction**: `Arshile Gorky is a painter; Eve Beglarian is a composer`
- **Primary Root Cause**: `F3_generation_failure`
- **Diagnostic Explanation**: The required evidence was present in the compressed prompt, but the LLM hallucinated, missed it, or made a reasoning error.
- **Retrieved Passages**: Arshile Gorky, Shahen Khachatrian, Eve Beglarian, Eve Beglarian, Giacomo Casanova

#### Ground-Truth Supporting Facts:
> 🔍 Arshile Gorky ( ; born Vostanik Manoug Adoian, Armenian: Ոստանիկ Մանուկ Ատոյեան ; April 15, 1904 – July 21, 1948) was an Armenian-American painter, who had a seminal influence on Abstract Expressionism.
> 🔍 Eve Beglarian (born Ann Arbor, Michigan, U.S., July 22, 1958) is a contemporary American composer, performer and audio producer of Armenian descent.

#### Selected EARC Sentences:
- ✅ Arshile Gorky ( ; born Vostanik Manoug Adoian, Armenian: Ոստանիկ Մանուկ Ատոյեան ; April 15, 1904 – July 21, 1948) was an Armenian-American painter, who had a seminal influence on Abstract Expressionism.
- ✅ Eve Beglarian (born Ann Arbor, Michigan, U.S., July 22, 1958) is a contemporary American composer, performer and audio producer of Armenian descent.
- ✅ Black Paintings: ISBN 0-8122-3956-3
* Glendinning, Nigel, «The Strange Translation of Goya's Black Paintings», The Burlingon Magazine, CXVII, 868, 1975.

#### Removed Candidate Sentences (Pruned by EARC):
- ❌ Arshile Gorky: Along with Mark Rothko, Jackson Pollock and Willem de Kooning, Gorky has been hailed as one of the most powerful American painters of the 20th century.
- ❌ Arshile Gorky: As such, his works were often speculated to have been informed by the suffering and loss he experienced in the Armenian Genocide.
- ❌ Arshile Gorky: He spent most his life as a national of the United States.

---

### Example 3 (ID: `hotpot_q0006515`, Dataset: `HOTPOT`, Model: `Ministral-8B`)
- **Question**: Name the Russian mixed martial artist who currently fights in the lightweight division of the UFC and is a training partner of Natalia Vitalyevna Vorobieva, a Russian wrestler who competed in the 2012 Summer Olympics?
- **Gold Answer**: `['Islam Makhachev']`
- **Generated Raw Answer**: `Final answer: Alexander Sarnavskiy`
- **Normalized Prediction**: `Alexander Sarnavskiy`
- **Primary Root Cause**: `F3_generation_failure`
- **Diagnostic Explanation**: The required evidence was present in the compressed prompt, but the LLM hallucinated, missed it, or made a reasoning error.
- **Retrieved Passages**: Natalia Vorobieva, Tatiana Suarez, Alexander Sarnavskiy, Valeria Koblova, Alexander Volkov (fighter)

#### Ground-Truth Supporting Facts:
> 🔍 Natalia Vitalyevna Vorobieva (Russian: Наталья Витальевна Воробьёва ; born 27 May 1991 in Tulun, Irkutsk oblast, Russian SFSR, Soviet Union) is a Russian wrestler, who competed at the 2012 Summer Olympics.
> 🔍  Vorobyeva train with UFC and M-1 Global MMA fighters, such as Khabib Nurmagomedov, Islam Makhachev, Vyacheslav Vasilevsky, Abubakar Nurmagomedov, Mikhail Malyutin, Ali Bagov.
> 🔍 Islam Ramazanovich Makhachev (Russian: Ислам Рамазанович Махачев ; born October 27, 1991 in Dagestan) is a Russian mixed martial artist, judoka and sambist of Lak origin.

#### Selected EARC Sentences:
- ✅ Natalia Vorobieva: Natalia Vitalyevna Vorobieva (Russian: Наталья Витальевна Воробьёва ; born 27 May 1991 in Tulun, Irkutsk oblast, Russian SFSR, Soviet Union) is a Russian wrestler, who competed at the 2012 Summer Olympics.
- ✅ Alexander Volkov (fighter): Alexander Yevgenievich Volkov (Russian: Александр Евгеньевич Волков ; born October 24, 1988) is a Russian mixed martial artist who competes in the UFC heavyweight division.
- ✅ Alexander Sarnavskiy (born January 17, 1989) is an Ethnic Russian mixed martial artist who competes in the lightweight division.

#### Removed Candidate Sentences (Pruned by EARC):
- ❌ Natalia Vorobieva: Vorobyeva train with UFC and M-1 Global MMA fighters, such as Khabib Nurmagomedov, Islam Makhachev, Vyacheslav Vasilevsky, Abubakar Nurmagomedov, Mikhail Malyutin, Ali Bagov.
- ❌ Alexander Sarnavskiy: A professional MMA competitor since 2008, Sarnavskiy has mostly competed in his native Russia, where he is an M-1 Global veteran and former lightweight division in the Bellator Fighting Championships.
- ❌ Valeria Koblova: Valeria Sergeyevna Koblova, née Zholobova (Russian: Валерия Сергеевна Коблова ; born 9 October 1992 in Moscow Oblast) is a Russian freestyle wrestler.

---

### Example 4 (ID: `hotpot_q0000212`, Dataset: `HOTPOT`, Model: `Ministral-8B`)
- **Question**: Jonas Hummels is the younger brother of a German professional footballer who plays for the German national team, and who else?
- **Gold Answer**: `['Bayern Munich']`
- **Generated Raw Answer**: `Final answer: Mats Hummels`
- **Normalized Prediction**: `Mats Hummels`
- **Primary Root Cause**: `F3_generation_failure`
- **Diagnostic Explanation**: The required evidence was present in the compressed prompt, but the LLM hallucinated, missed it, or made a reasoning error.
- **Retrieved Passages**: Jonas Hummels, Jonas Hummels, Mats Hummels, Mats Hummels, Jonas Troest

#### Ground-Truth Supporting Facts:
> 🔍  He is the younger brother of German international Mats Hummels, and the son of Hermann Hummels, a former footballer and manager.
> 🔍 Mats Julian Hummels (] ; born 16 December 1988) is a German professional footballer who plays as a central defender for Bayern Munich and the Germany national team.

#### Selected EARC Sentences:
- ✅ Jonas Hummels: He is the younger brother of German international Mats Hummels, and the son of Hermann Hummels, a former footballer and manager.
- ✅ Mats Hummels: Mats Julian Hummels (] ; born 16 December 1988) is a German professional footballer who plays as a central defender for Bayern Munich and the Germany national team.
- ✅ Jonas Hector: Jonas Armin Hector (born 27 May 1990) is a German professional footballer who plays as a left back for Bundesliga club 1.

#### Removed Candidate Sentences (Pruned by EARC):
- ❌ Jonas Troest: He has played 25 matches for the Danish under-21 national team.
- ❌ Jonas Troest is the older brother of footballer Magnus Troest.
- ❌ Tobias Schweinsteiger: He is the older brother of former German international and Chicago Fire player Bastian Schweinsteiger.

---

### Example 5 (ID: `hotpot_q0005094`, Dataset: `HOTPOT`, Model: `Ministral-8B`)
- **Question**: The National Education Goals Panel discontinued their reports by the Act that reauthorized which piece of legislation?
- **Gold Answer**: `['Elementary and Secondary Education Act']`
- **Generated Raw Answer**: `Final answer: No Child Left Behind Act`
- **Normalized Prediction**: `No Child Left Behind Act`
- **Primary Root Cause**: `F3_generation_failure`
- **Diagnostic Explanation**: The required evidence was present in the compressed prompt, but the LLM hallucinated, missed it, or made a reasoning error.
- **Retrieved Passages**: National Education Goals Panel, No Child Left Behind Act, Education Consolidation and Improvement Act, Factory Acts, Education Act 1944

#### Ground-Truth Supporting Facts:
> 🔍  The panel issued many reports between 1991 and 1999, and it was discontinued by the No Child Left Behind Act which became law in January, 2002.
> 🔍 The No Child Left Behind Act of 2001 (NCLB) was a U.S. Act of Congress that reauthorized the Elementary and Secondary Education Act; it included Title I provisions applying to disadvantaged students.

#### Selected EARC Sentences:
- ✅ National Education Goals Panel: The panel issued many reports between 1991 and 1999, and it was discontinued by the No Child Left Behind Act which became law in January, 2002.
- ✅ Education Act 1944: The Act renamed the Board of Education as the Ministry of Education, giving it greater powers and a bigger budget, ended fee-paying for state secondary schools, and enforced the division between primary (5–11 years old) and secondary (11–15 years old) that many local authorities had already introduced.
- ✅ No Child Left Behind Act The No Child Left Behind Act of 2001(NCLB)[1][2] was a U.S. Act of Congress that reauthorized the Elementary and Secondary Education Act; it included Title I provisions applying to disadvantaged students.[3]

#### Removed Candidate Sentences (Pruned by EARC):
- ❌ National Education Goals Panel: The 1994 Goals 2000 legislation formally established the National Education Goals Panel in federal law, and the legislation assigned it annual reporting responsibilities.
- ❌ National Education Goals Panel: The organization was established to report on the nation's progress toward the six education goals adopted at the Charlottesville meeting.
- ❌ Education Act 1944: The Education Act 1944 (7 and 8 Geo 6 c. 31) made numerous major changes in the provision and governance of secondary schools in England and Wales.

---

## F4. Answer Extraction / Evaluation Failure (Semantically correct, but regex/EM marked 0)

### Example 1 (ID: `hotpot_q0018390`, Dataset: `HOTPOT`, Model: `Ministral-8B`)
- **Question**: Judith "Judy" Jacobs, was the presiding officer of the Nassau County legislature, in her fifth term as a legislator, Jacobs represented legislative district 16, which included Old Westbury, a village in Nassau County, in the U.S. state of New York, on the North Shore, of which location?
- **Gold Answer**: `['Long Island']`
- **Generated Raw Answer**: `Final answer: North Shore of Long Island`
- **Normalized Prediction**: `North Shore of Long Island`
- **Primary Root Cause**: `F4_evaluation_failure`
- **Diagnostic Explanation**: The LLM response contains the correct answer semantically, but format/extraction marked EM=0.
- **Retrieved Passages**: Judith Jacobs, Old Westbury, New York, Salisbury, Nassau County, New York, Salisbury, Nassau County, New York, Harold G. Hoffman

#### Ground-Truth Supporting Facts:
> 🔍  In her fifth term as a legislator, Jacobs represented legislative district 16, which includes: Woodbury; Jericho; Plainview; Old Westbury; Roslyn Heights; and parts of Syosset; Old Bethpage; and Roslyn Estates Her district in the past also included Bethpage, Cove Neck, East Norwich, Jericho, Laurel Hollow, Muttontown, Oyster Bay, Oyster Bay Cove, Plainview, Syosset, and Woodbury.
> 🔍 Old Westbury is a village in Nassau County, in the U.S. state of New York, on the North Shore of Long Island.

#### Selected EARC Sentences:
- ✅ Judith Jacobs: Judith "Judy" Jacobs (January 13, 1939 – September 13, 2016) was the presiding officer of the Nassau County legislature.
- ✅ Old Westbury, New York: Old Westbury is a village in Nassau County, in the U.S. state of New York, on the North Shore of Long Island.
- ✅ Monmouth County, New Jersey: As of the 2016 Census estimate, the county's population was 625,846, making it the state's fifth-most populous county, representing a decrease of 0.7% from the 2010 Census, when the population was enumerated at 630,380, in turn an increase of 15,079 from 615,301 at the 2000 Census.

#### Removed Candidate Sentences (Pruned by EARC):
- ❌ Judith Jacobs: In her fifth term as a legislator, Jacobs represented legislative district 16, which includes: Woodbury; Jericho; Plainview; Old Westbury; Roslyn Heights; and parts of Syosset; Old Bethpage; and Roslyn Estates
- ❌ Judith Jacobs: She was elected to the newly formed legislature in 1995, and was chair or vice-chair of a number of committees: rules and procedures; planning, development and the environment; legislative budget review; and government services and operations.
- ❌ Old Westbury, New York: As of the 2010 United States Census, the village population was 4,671.

---

### Example 2 (ID: `hotpot_q0017856`, Dataset: `HOTPOT`, Model: `Ministral-8B`)
- **Question**: "Finest Worksong" is the third and final single released from which American rock band that formed in Athens, Georgia, in 1980, and their fifth studio album "Document"?
- **Gold Answer**: `['R.E.M.']`
- **Generated Raw Answer**: `Final answer: R.E.M.`
- **Normalized Prediction**: `R`
- **Primary Root Cause**: `F4_evaluation_failure`
- **Diagnostic Explanation**: The LLM response contains the correct answer semantically, but format/extraction marked EM=0.
- **Retrieved Passages**: Finest Worksong, Finest Worksong, Thriller (Michael Jackson album), Thriller (Michael Jackson album), Ah Via Musicom

#### Ground-Truth Supporting Facts:
> 🔍 "Finest Worksong" is the third and final single released from R.E.M.'s fifth studio album "Document".
> 🔍 R.E.M. was an American rock band that formed in Athens, Georgia, in 1980 by lead singer Michael Stipe, guitarist Peter Buck, bassist/backing vocalist Mike Mills, and drummer Bill Berry.

#### Selected EARC Sentences:
- ✅ Finest Worksong: "Finest Worksong" is the third and final single released from R.E.M.'s fifth studio album "Document".
- ✅ Kajagoogoo: Members

*Steve Askew - guitars, programming, backing vocals (1978-1985, 2003-2004, 2007-present)
*Nick Beggs - bass guitar, Chapman Stick, guitars, keyboards, programming, percussion, lead & backing vocals (1978-1985, 2003-2004, 2007-present)
*Stuart Neale - keyboards, programming, backing vocals (1978-1985, 2003-2004, 2007-present)
*Jez Strode - drums, percussion (1978-1984, 2003, 2008-present)
*Limahl - lead vocals (1982-1983, 2003, 2008-present)

Discography

Studio albums

* 1983 – White Feathers
* 198
- ✅ Thriller (Michael Jackson album): Jerry Hey – trumpet (tracks 1–2, 4), flugelhorn (1–2, 4), horn arrangements (1–2, 4), string arrangements (3, 6), strings conductor (3)
* Janet Jackson – background vocals on "PYT"
* La Toya Jackson – background vocals on "PYT

#### Removed Candidate Sentences (Pruned by EARC):
- ❌ Finest Worksong: It peaked at number 50 on the UK Singles Chart in April 1988, at the time the group's highest-charting single in the UK.
- ❌ Thriller (Michael Jackson album): Track listing

Personnel

* Brian Banks – keyboards, synthesizer (track 4), synthesizer programming (2)
* Michael Boddicker – keyboards, synthesizers (tracks 1–2), Emulator (6–9), Vocoder (8)
* N'dugu Chancler – drums (tracks 2, 6, 8)
*
- ❌ Ah Via Musicom is the third studio album by guitarist Eric Johnson, released in 1990 through Capitol Records.

---

### Example 3 (ID: `hotpot_q0005231`, Dataset: `HOTPOT`, Model: `Ministral-8B`)
- **Question**: The Curse of Rocky Colavito is one of several sports superstitions centered on the failure to win a championship in any major league sport for how many years?
- **Gold Answer**: `['52']`
- **Generated Raw Answer**: `Final answer: 52 years`
- **Normalized Prediction**: `52 years`
- **Primary Root Cause**: `F4_evaluation_failure`
- **Diagnostic Explanation**: The LLM response contains the correct answer semantically, but format/extraction marked EM=0.
- **Retrieved Passages**: Curse of Rocky Colavito, Cleveland sports curse, Cleveland sports curse, 1965 Cleveland Indians season, 1996–97 Portland Trail Blazers season

#### Ground-Truth Supporting Facts:
> 🔍 The Curse of Rocky Colavito is a sports-related curse that supposedly prevents the Cleveland Indians Major League Baseball (MLB) franchise from winning, be it the World Series, the American League (AL) pennant, reaching postseason play, or even getting into a pennant race.
> 🔍  It is one of several curses believed to have stricken the city of Cleveland's major sports franchises for decades.
> 🔍 The Cleveland sports curse was a sports superstition involving the city of Cleveland, Ohio, and its major league professional sports teams, centered on the failure to win a championship in any major league sport for a period of 52 years, from 1964 to 2016.

#### Selected EARC Sentences:
- ✅ Cleveland sports curse: The Cleveland sports curse was a sports superstition involving the city of Cleveland, Ohio, and its major league professional sports teams, centered on the failure to win a championship in any major league sport for a period of 52 years, from 1964 to 2016.
- ✅ Curse of Rocky Colavito: It is one of several curses believed to have stricken the city of Cleveland's major sports franchises for decades.
- ✅ in Major League Baseball.[4][5] The 108-year drought was also the longest such occurrence in all major North American sports.

#### Removed Candidate Sentences (Pruned by EARC):
- ❌ Curse of Rocky Colavito: Its origin is traced back to the unpopular trade of right fielder Rocky Colavito to the Detroit Tigers for Harvey Kuenn in 1960.
- ❌ Cleveland sports curse: Combined with the short-lived Barons franchise of the National Hockey League (NHL), Cleveland teams endured an unprecedented 147-season championship drought, having not won a title since the Browns defeated the Baltimore Colts in the 1964 NFL Championship Game two seasons prior to the first Super Bowl.
- ❌ Curse of Rocky Colavito: It was not claimed that Colavito placed the curse, and he has denied doing so.

---

### Example 4 (ID: `hotpot_q0003039`, Dataset: `HOTPOT`, Model: `Ministral-8B`)
- **Question**: MedStar Georgetown University Hospital and Walter Reed Army Medical Center, are both which type of medical facilities?
- **Gold Answer**: `['Hospital']`
- **Generated Raw Answer**: `Final answer: **military medical center (Walter Reed) and academic/affiliated hospital (MedStar Georgetown)**`
- **Normalized Prediction**: `**military medical center (Walter Reed) and academic/affiliated hospital (MedStar Georgetown)**`
- **Primary Root Cause**: `F4_evaluation_failure`
- **Diagnostic Explanation**: The LLM response contains the correct answer semantically, but format/extraction marked EM=0.
- **Retrieved Passages**: MedStar Georgetown University Hospital, MedStar Georgetown University Hospital, MedStar Georgetown University Hospital, MedStar Georgetown University Hospital, Building 40 (Army Medical School)

#### Ground-Truth Supporting Facts:
> 🔍 MedStar Georgetown University Hospital is one of the national capital area's oldest academic teaching hospitals.
> 🔍 The Walter Reed Army Medical Center (WRAMC) — known as Walter Reed General Hospital (WRGH) until 1951 — was the U.S. Army's flagship medical center from 1909 to 2011.

#### Selected EARC Sentences:
- ✅ Walter Reed Army Medical Center: Located on 113 acre in Washington, D.C., it served more than 150,000 active and retired personnel from all branches of the military.
- ✅ MedStar Georgetown University Hospital: MedStar Georgetown is co-located with the Georgetown University Medical Center and is affiliated with the Georgetown University School of Medicine.
- ✅ Building 40 (Army Medical School): It was built between 1922 and 1932 to house the Army Medical School, which became the Army Medical Center in 1923 when it — under the name “Medical Department Professional Service School” (MDPSS) — combined with the Walter Reed General Hospital.

#### Removed Candidate Sentences (Pruned by EARC):
- ❌ Walter Reed Army Medical Center: The Walter Reed Army Medical Center (WRAMC) — known as Walter Reed General Hospital (WRGH) until 1951 — was the U.S. Army's flagship medical center from 1909 to 2011.
- ❌ MedStar Georgetown University Hospital: It is a not-for-profit, acute care teaching and research facility located in the Georgetown neighborhood of the Northwest Quadrant of Washington, D.C.
- ❌ MedStar Georgetown University Hospital: MedStar Georgetown is home to the internationally known Lombardi Comprehensive Cancer Center, as well as centers of excellence in the neurology, neurosurgery, psychiatry, gastroenterology, transplant and vascular surgery.

---

### Example 5 (ID: `hotpot_q0003169`, Dataset: `HOTPOT`, Model: `Ministral-8B`)
- **Question**: Where does the American rock band Drowning Pool, named after a movie, who feature on the official soundtrack for the film 'The Punisher', hail from?
- **Gold Answer**: `['Dallas']`
- **Generated Raw Answer**: `Final answer: Dallas, Texas`
- **Normalized Prediction**: `Dallas, Texas`
- **Primary Root Cause**: `F4_evaluation_failure`
- **Diagnostic Explanation**: The LLM response contains the correct answer semantically, but format/extraction marked EM=0.
- **Retrieved Passages**: Drowning Pool, The Punisher: The Album, Drowning Pool (album), Deadwater Drowning, Resilience (Drowning Pool album)

#### Ground-Truth Supporting Facts:
> 🔍 The Punisher: The Album is the official soundtrack for the film "The Punisher" and was released in 2004 by Wind-up Records.
> 🔍  Its lead singles were "Broken" by Seether and Evanescence frontwoman Amy Lee, "Step Up" by Drowning Pool, and "Eyes Wired Shut" by Edgewater, all of which have accompanying music videos.
> 🔍 Drowning Pool is an American rock band formed in Dallas, Texas in 1996.

#### Selected EARC Sentences:
- ✅ Drowning Pool: The band was named after the film "The Drowning Pool".
- ✅ Drowning Pool (album): It was released on April 27, 2010 and is the band's first album not to feature a different singer, as Ryan McCombs remained with Drowning Pool after their 2007 album "Full Circle", although he did, however, leave the band in 2011 to rejoin his previous band SOiL.
- ✅ The Punisher: The Album is the official soundtrack for the film "The Punisher" and was released in 2004 by Wind-up Records.

#### Removed Candidate Sentences (Pruned by EARC):
- ❌ Drowning Pool is an American rock band formed in Dallas, Texas in 1996.
- ❌ Drowning Pool (album): Drowning Pool is the eponymous fourth studio album by American rock band Drowning Pool.
- ❌ Drowning Pool: The band's current vocalist is Jasen Moreno.

---
