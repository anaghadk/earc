# Qualitative Case Studies — Multi-Hop Evidence Preservation in EARC

This document inspects representative HotpotQA questions across three diagnostic failure/success regimes:
- **Category A**: EARC preserves all supporting evidence and the LLM answers correctly.
- **Category B**: EARC removes required multi-hop evidence and the LLM answers incorrectly.
- **Category C**: EARC preserves all required evidence, but the LLM still answers incorrectly (reasoning/synthesis failure).

## CATEGORY A ALL EVIDENCE PRESERVED AND CORRECT

### Example 1 (ID: `hotpot_q0011149`)
- **Question**: Which came out first, "Hollywood Chinese" or "The Truth According to Wikipedia"?
- **Gold Answer**: `['Hollywood Chinese']`
- **Generated Answer**: `*Hollywood Chinese*`
- **Retrieved Passages**: The Truth According to Wikipedia, The Truth According to Wikipedia, Hollywood Chinese, Chinese American literature, Charlie Chan

#### Gold Supporting Facts:
> 🔍 Hollywood Chinese: The Chinese in American Feature Films is a 2007 American documentary film directed by Academy Award-nominated director Arthur Dong.
> 🔍  It was screened at The Next Web conference in Amsterdam on 4 April 2008 and broadcast by the Dutch documentary series "Backlight" (Dutch: "Tegenlicht" ) on Nederland 2 on 7 April 2008.

#### Selected EARC Sentences:
- ✅ The Truth According to Wikipedia: It was screened at The Next Web conference in Amsterdam on 4 April 2008 and broadcast by the Dutch documentary series "Backlight" (Dutch: "Tegenlicht" ) on Nederland 2 on 7 April 2008.
- ✅ Qin Shi Huang (2001 TV series): The series was filmed between 1999 and 2000 and was first released in 2001 in Hong Kong and Thailand and in 2002 in Singapore.
- ✅ Hollywood Chinese: The Chinese in American Feature Films is a 2007 American documentary film directed by Academy Award-nominated director Arthur Dong.
- ✅ Serial (literature): Chinese University Press, January 1, 1975.

#### Removed Sentences (Pruned by Budget/Redundancy):
- ❌ The Truth According to Wikipedia, also referred to as Wiki's Truth (Dutch: Wiki's Waarheid ), is a Dutch documentary about Wikipedia directed by Ijsbrand van Veelen.
- ❌ Charlie Chan: They were by far the most popular American films in 1930s China and among Chinese expatriates; "one of the reasons for this acceptance was this was the first time Chinese audiences saw a positive Chinese character in an American film, a departure from the sinister East Asian stereotypes in earlier movies like Thief of Baghdad  and Welcome Danger, which incited riots that shut down the Shanghai theater showing it."
- ❌ Serial (literature): The Chinese Novel at the Turn of the Century (Toronto: University of Toronto Press; January 1, 1980), ISBN 0802054730, 9780802054739.

---

### Example 2 (ID: `hotpot_q0007055`)
- **Question**: Which water park opened in Kansas City in 2009 and featured a slide named after the German word fro crazy?
- **Gold Answer**: `['Schlitterbahn Kansas City']`
- **Generated Answer**: `Schlitterbahn Kansas City`
- **Retrieved Passages**: Schlitterbahn Kansas City, Oceans of Fun, Verrückt (water slide), Worlds of Fun, Worlds of Fun

#### Gold Supporting Facts:
> 🔍 Verrückt (German for "crazy" or "insane") was a water slide at the Schlitterbahn Kansas City water park.
> 🔍 Schlitterbahn Waterpark Kansas City is a water park that opened in summer 2009 in Kansas City, Kansas.

#### Selected EARC Sentences:
- ✅ Verrückt (water slide): Verrückt (German for "crazy" or "insane") was a water slide at the Schlitterbahn Kansas City water park.
- ✅ Schlitterbahn Kansas City: Schlitterbahn Waterpark Kansas City is a water park that opened in summer 2009 in Kansas City, Kansas.
- ✅ Wild West World was a Wild West theme park in Park City, Kansas that opened on May 5, 2007 and closed on July 9, 2007.
- ✅ Oceans of Fun is a tropically-themed water park that opened on May 31, 1982, in Kansas City, Missouri, to celebrate Worlds of Fun's 10th year anniversary.

#### Removed Sentences (Pruned by Budget/Redundancy):
- ❌ Verrückt (water slide): At 168 ft , the slide surpassed Kilimanjaro at Aldeia das Águas Park Resort to become the world's tallest water slide when it opened in 2014.
- ❌ Schlitterbahn Kansas City: The 370 acre , $750 million development will include a nearly 40 acre waterpark, which will be Schlitterbahn's fourth waterpark and its first outside Texas.
- ❌ Schlitterbahn Kansas City: It was announced in September 2005 by Schlitterbahn Waterparks.

---

### Example 3 (ID: `hotpot_q0011029`)
- **Question**: Richard Dull resigned as the athletic director of the University of Maryland after the death of a played selected in the 1986 NBA draft by what team?
- **Gold Answer**: `['Boston Celtics']`
- **Generated Answer**: `Boston Celtics`
- **Retrieved Passages**: Dick Dull, Ronald Dupree, Len Bias, Tom Osborne, Rick Wilson (basketball)

#### Gold Supporting Facts:
> 🔍  He served as the athletic director of the University of Maryland from 1981 to 1986, including during the death of Len Bias, which prompted Dull's resignation.
> 🔍  He was selected by the Boston Celtics as the second overall pick in the 1986 NBA draft on June 17, and died two days later from cardiac arrhythmia induced by a cocaine overdose.

#### Selected EARC Sentences:
- ✅ Dick Dull: He served as the athletic director of the University of Maryland from 1981 to 1986, including during the death of Len Bias, which prompted Dull's resignation.
- ✅ John Killilea: He served as the assistant coach to four National Basketball Association (NBA) team; the Boston Celtics (1972–77), the Milwaukee Bucks (1977–1983), the New Jersey Nets (1983–85), the Houston Rockets (1989–1993).
- ✅ Jack Lengyel: Lengyel was the athletic director at California State University, Fresno from 1983 to 1986, at the University of Missouri from 1986 to 1988, and at the United States Naval Academy from 1988 to 2001.
- ✅ Len Bias: He was selected by the Boston Celtics as the second overall pick in the 1986 NBA draft on June 17, and died two days later from cardiac arrhythmia induced by a cocaine overdose.

#### Removed Sentences (Pruned by Budget/Redundancy):
- ❌ Dick Dull: Richard Dull (born c. 1945) is an American former athletic director and athlete.
- ❌ Len Bias: Leonard Kevin Bias (November 18, 1963 – June 19, 1986) was a first-team All-American college basketball forward at the University of Maryland.
- ❌ Dick Dull: He has also been athletic director at the University of Nebraska at Kearney, Moravian College, California State University, Northridge, and Belmont Abbey College.

---

### Example 4 (ID: `hotpot_q0014857`)
- **Question**: What Monorail system travels to the Hyperion Bridge replica in California Adventure?
- **Gold Answer**: `['The Disneyland Monorail System']`
- **Generated Answer**: `Disneyland Monorail System`
- **Retrieved Passages**: Seattle Center Monorail, Disneyland Monorail System, Buena Vista Street, Glendale-Hyperion Bridge, West Virginia

#### Gold Supporting Facts:
> 🔍  The replica functions as a working bridge for the resort's monorail system.
> 🔍 The Disneyland Monorail System (originally named the Disneyland ALWEG Monorail System) is an attraction and transportation system at the Disneyland Resort in Anaheim, California, United States.

#### Selected EARC Sentences:
- ✅ Buena Vista Street: The replica functions as a working bridge for the resort's monorail system.
- ✅ Glendale-Hyperion Bridge: The bridge has become more widely known since the building of a small-scale replica at Disney California Adventure in Anaheim, California.
- ✅ Walt Disney World Monorail System: It was expanded to three lines (Magic Kingdom: Resort and Express, plus Epcot) in 1982, and the rolling stock was updated to Mark VI trains in 1989.
- ✅ Seattle Center Monorail: It was given historical landmark status by the Seattle Landmarks Preservation Board April 16, 2003.

#### Removed Sentences (Pruned by Budget/Redundancy):
- ❌ Glendale-Hyperion Bridge: The Hyperion Bridge was constructed in 1927 by vote of the citizens that lived in Atwater Village at the time and was completed in February 1929.
- ❌ Walt Disney World Monorail System: The monorail system opened in 1971 with two routes (Magic Kingdom: Resort and Express) and with Mark IV monorail trains.
- ❌ Glendale-Hyperion Bridge: The Glendale-Hyperion Bridge is a concrete arch bridge viaduct in Atwater Village that spans the Los Angeles River and Interstate 5.

---

## CATEGORY B REQUIRED EVIDENCE REMOVED AND INCORRECT

### Example 1 (ID: `hotpot_q0003648`)
- **Question**: What is the birth date of this English scientist, whose laboratory burner design was later perfected by Peter Desaga into the Bunsen burner?
- **Gold Answer**: `['22 September 1791']`
- **Generated Answer**: `Michael Faraday`
- **Retrieved Passages**: Peter Desaga, Robert Bunsen, Robert Bunsen, Robert Bunsen, Bunsen burner

#### Gold Supporting Facts:
> 🔍 Peter Desaga was a German instrument maker at the University of Heidelberg who worked with Robert Wilhelm Bunsen.
> 🔍  In 1855, Desaga perfected an earlier design of the laboratory burner by Michael Faraday into the Bunsen burner.
> 🔍 Michael Faraday FRS ( ; 22 September 1791 – 25 August 1867) was an English scientist who contributed to the study of electromagnetism and electrochemistry.

#### Selected EARC Sentences:
- ✅ Peter Desaga: In 1855, Desaga perfected an earlier design of the laboratory burner by Michael Faraday into the Bunsen burner.
- ✅ Robert Bunsen: For this work, Bunsen and his laboratory assistant, Peter Desaga, had perfected a special gas burner by 1855, which was influenced by earlier models.
- ✅ 17th century: * Galileo Galilei, Italian natural philosopher (1564–1642)
* Pierre Gassendi, (1592–1655), French philosopher, priest, scientist, astronomer/astrologer, and mathematician
* William Harvey, medical doctor (1578–1657)
* Thomas Hobbes, English philosopher and mathematician (1588–1679)
* Christiaan Huygens, Dutch mathematician, physicist and astronomer (1629–1695)
* Johannes Kepler, German astronomer (1571–1630)
* Antonie van Leeuwenhoek, Dutch scientist and the first person to use a microscope to view bacteria (16
- ✅ 1883: November 19 – Carl Wilhelm Siemens, German engineer (b. 1823)
* December 13 – Victor de Laprade, French poet and critic (b. 1812)
* December 27 – Andrew A. Humphreys, American general and civil engineer (b. 1810)

Dates unknown

*Margaret Agnes Bunn, British actress, (b. 1799)

#### Removed Sentences (Pruned by Budget/Redundancy):
- ❌ Robert Bunsen: With his laboratory assistant, Peter Desaga, he developed the Bunsen burner, an improvement on the laboratory burners then in use.
- ❌ Peter Desaga: The Bunsen burner was essential to the invention of the spectroscope by Robert Wilhelm Bunsen and Gustav Robert Georg Kirchhoff.
- ❌ Robert Bunsen: The newer design of Bunsen and Desaga, which provided a very hot and clean flame, is now called simply the "Bunsen burner", a common laboratory equipment.

---

### Example 2 (ID: `hotpot_q0000819`)
- **Question**: Where is a place that has both Lano Estacado and Buda Limestone geological formations?
- **Gold Answer**: `['High Plains']`
- **Generated Answer**: `Andes`
- **Retrieved Passages**: Buda Limestone, Patagonia, Patagonia, Easter Island, Easter Island

#### Gold Supporting Facts:
> 🔍 The Buda Limestone is a geological formation in the High Plains and Trans-Pecos regions of West Texas whose strata date back to the Late Cretaceous.
> 🔍  The southern region of the Western High Plains ecology region contains the geological formation known as Llano Estacado which can be seen from a short distance or from on satellite maps.

#### Selected EARC Sentences:
- ✅ Andes: near Otavalo
File:Historic Center of Quito - World Heritage Site by UNESCO - Photo 186.JPG|Pichincha Volcano, an active stratovolcano in the Ecuadorian Andes photographed from the Historic Center of Quito
File:Andes Mountains South America Photograph 022.JPG|Imbabura Volcano, an inactive stratovolcano

Peru

* Alpamayo, 5947 m
* Artesonraju, 6025 m
* Carnicero, 5960 m
* Chumpi, 6106 m
* Coropuna, 6377 m
* El Misti, 5822 m
* El Toro, 5830 m
* Huandoy, 6395 m
* Huascarán, 6768 m
* Jirishanca, 6094 m
* Pumasillu, 5991 m
* Rasaq, 6040 m
* Runtuy, 5870 m
* Sarapu, 6127 m
* Salcantay, 6271 m
* Seria Norte, 5860 m
* Siula Grande, 6344 m
* Waytapallana, 5557 m
* Yerupaja, 6635 m
*
- ✅ Minas Gerais: Recent advances in env
- ✅ Patagonia: It generally separates

#### Removed Sentences (Pruned by Budget/Redundancy):
- ❌ Buda Limestone: The Buda Limestone is a geological formation in the High Plains and Trans-Pecos regions of West Texas whose strata date back to the Late Cretaceous.
- ❌ Buda Limestone: Pterosaur remains are among the fossils that have been recovered from the formation.
- ❌ Minas Gerais: Around Lagoa Santa and Sete Lagoas a typical Karst topography with caves and lakes is found.

---

### Example 3 (ID: `hotpot_q0009012`)
- **Question**: what mutiny in India was thwarted by MI5(b) during World War I?
- **Gold Answer**: `['The February mutiny']`
- **Generated Answer**: `Hindu–German Mutiny`
- **Retrieved Passages**: Hindu–German Conspiracy, MI5(g), Ghadar Mutiny, Mutiny, Indian independence movement

#### Gold Supporting Facts:
> 🔍  Another subsection, the MI5(b), was formed in January 1917 to deal specifically with Indians and "other oriental races".
> 🔍  The February mutiny was ultimately thwarted when British intelligence infiltrated the Ghadarite movement and arrested key figures.

#### Selected EARC Sentences:
- ✅ Mutiny: After World War II

* Post–World War II demobilization strikes occurred within Allied military forces stationed across the Middle East, India and South-East Asia in the months and years following World War II.
- ✅ ] and was contained only with the rebels' defeat in Gwalior on 20 June 1858.[10] On 1 November 1858, the British granted amnesty to all rebels not involved in murder, though they did not declare the hostilities formally to have ended until 8 July 1859.
- ✅ Ghadar Mutiny: It was the most prominent amongst a number of plans of the much larger Hindu–German Mutiny, formulated between 1914 and 1917 to initiate a Pan-Indian rebellion against the British Raj during World War I.
- ✅ MI5(g): The MI5(g) had 27 officers in its staff, eight of whom had served in India before the war.

#### Removed Sentences (Pruned by Budget/Redundancy):
- ❌ Mutiny: The Royal Indian Navy Mutiny encompasses a total strike and subsequent mutiny by the Indian sailors of the Royal Indian Navy on board ship and shore establishments  at Bombay (Mumbai) harbour on 18 February 1946.
- ❌ The rebellion is known by many names, including the Sepoy Mutiny, the Indian Mutiny, the Great Rebellion, the Revolt of 1857, the Indian Insurrection, and India's First War of Independence.[e][11]
- ❌ MI5(g): The MI5 itself, working under Vernon Kell, had a number of India experts at the beginning of the war.

---

### Example 4 (ID: `hotpot_q0007314`)
- **Question**: Who was the leader of the secret police of Nazi Germany?
- **Gold Answer**: `['Eugen Schwitzgebel']`
- **Generated Answer**: `Heinrich Müller`
- **Retrieved Passages**: Gestapo, Gestapo, Gestapo, Heinrich Müller (Gestapo), Gestapo

#### Gold Supporting Facts:
> 🔍 Eugen Schwitzgebel (1900 – 31 October 1944, in Aarhus) was a German officer, a SS Sturmbannführer and Gestapo leader in Aarhus during the Second World War.
> 🔍 The Gestapo (] ), abbreviation of Geheime Staatspolizei, or the Secret State Police, was the official secret police of Nazi Germany and German-occupied Europe.

#### Selected EARC Sentences:
- ✅ Heinrich Müller (Gestapo): Heinrich Müller (28 April 1900; date of death unknown, but evidence points to May 1945) was a German police official under both the Weimar Republic and Nazi Germany.
- ✅ Gestapo: *Klaus Barbie (SiPo-SD Lyon)
*Werner Best (SiPo-SD Copenhagen)
*Karl Bömelburg (Head of Gestapo, Southern France)
*Theodor Dannecker (SiPo-SD Paris)
*Rudolf Diels (Chief 1933–1934)
*Adolf Eichmann (RSHA Berlin)
*Hans Ehlich
*Gerhard Flesch
*Hermann Göring (Founder of the Gestapo)
*Viktor Harnischfeger (Düsseldorf Gestapo Criminal Commissar)
*Reinhard Heydrich (SD, SiPo, Gestapo Chief 1934–1939, RSHA Chief 1939–1942)
*Hei
- ✅ Hans Oster: Hans Paul Oster (9 August 1887 – 9 April 1945) was a general in the Wehrmacht of Nazi Germany who was also a leading figure of the German resistance from 1938 to 1943.
- ✅ Heinrich Müller (Gestapo): He became chief of the Gestapo, the political secret state police of Nazi Germany, and was involved in the planning and execution of the Holocaust.

#### Removed Sentences (Pruned by Budget/Redundancy):
- ❌ Gestapo: Beginning on 20 April 1934, it was under the administration of SS national leader Heinrich Himmler, who in 1936 was appointed Chief of German Police (Chef der Deutschen Polizei) by Hitler.
- ❌ Gestapo: Organization

On January 1933, Hermann Göring, Hitler's minister without portfolio, was appointed the head of the Prussian Police and began filling the political and intelligence units of the Prussian Secret Police with Nazi Party members.
- ❌ Gestapo: *Heinrich Himmler (Reichsführer-SS)
*Ernst Kaltenbrunner (RSHA Chief 1943–1945)
*Herbert Kappler (SD Chief Rome)
*Helmut Knochen (Paris)
*Kurt Kohl (SiPo-SD Lille, France)
*Kurt Lischka (Paris)
*Ernst Misselwitz (Hauptscharführer SiPo-SD Paris)
*Violette Morris
*Heinrich Müller (Chief 1939–1945)
*Karl Oberg (Paris)
*Pierre Paoli (Head of Gestapo, Central France)
*Oswald Poche (Chief of Frankfurt Lindenstrasse station)
*Henry Oliver Rinnan
*Karl Eberhard Schöngarth
*Max Wielen

---

## CATEGORY C EVIDENCE RETAINED BUT LLM INCORRECT

### Example 1 (ID: `hotpot_q0004572`)
- **Question**: Are Arshile Gorky and Eve Beglarian both painters?
- **Gold Answer**: `['no']`
- **Generated Answer**: `Arshile Gorky is a painter; Eve Beglarian is a composer`
- **Retrieved Passages**: Arshile Gorky, Shahen Khachatrian, Eve Beglarian, Eve Beglarian, Giacomo Casanova

#### Gold Supporting Facts:
> 🔍 Arshile Gorky ( ; born Vostanik Manoug Adoian, Armenian: Ոստանիկ Մանուկ Ատոյեան ; April 15, 1904 – July 21, 1948) was an Armenian-American painter, who had a seminal influence on Abstract Expressionism.
> 🔍 Eve Beglarian (born Ann Arbor, Michigan, U.S., July 22, 1958) is a contemporary American composer, performer and audio producer of Armenian descent.

#### Selected EARC Sentences:
- ✅ Arshile Gorky ( ; born Vostanik Manoug Adoian, Armenian: Ոստանիկ Մանուկ Ատոյեան ; April 15, 1904 – July 21, 1948) was an Armenian-American painter, who had a seminal influence on Abstract Expressionism.
- ✅ Eve Beglarian (born Ann Arbor, Michigan, U.S., July 22, 1958) is a contemporary American composer, performer and audio producer of Armenian descent.
- ✅ Black Paintings: ISBN 0-8122-3956-3
* Glendinning, Nigel, «The Strange Translation of Goya's Black Paintings», The Burlingon Magazine, CXVII, 868, 1975.
- ✅ Shahen Khachatrian: He is the founding director of the Arshile Gorky Museum in Etchmiadzin.

#### Removed Sentences (Pruned by Budget/Redundancy):
- ❌ Arshile Gorky: Along with Mark Rothko, Jackson Pollock and Willem de Kooning, Gorky has been hailed as one of the most powerful American painters of the 20th century.
- ❌ Arshile Gorky: As such, his works were often speculated to have been informed by the suffering and loss he experienced in the Armenian Genocide.
- ❌ Arshile Gorky: He spent most his life as a national of the United States.

---

### Example 2 (ID: `hotpot_q0000212`)
- **Question**: Jonas Hummels is the younger brother of a German professional footballer who plays for the German national team, and who else?
- **Gold Answer**: `['Bayern Munich']`
- **Generated Answer**: `Mats Hummels`
- **Retrieved Passages**: Jonas Hummels, Jonas Hummels, Mats Hummels, Mats Hummels, Jonas Troest

#### Gold Supporting Facts:
> 🔍  He is the younger brother of German international Mats Hummels, and the son of Hermann Hummels, a former footballer and manager.
> 🔍 Mats Julian Hummels (] ; born 16 December 1988) is a German professional footballer who plays as a central defender for Bayern Munich and the Germany national team.

#### Selected EARC Sentences:
- ✅ Jonas Hummels: He is the younger brother of German international Mats Hummels, and the son of Hermann Hummels, a former footballer and manager.
- ✅ Mats Hummels: Mats Julian Hummels (] ; born 16 December 1988) is a German professional footballer who plays as a central defender for Bayern Munich and the Germany national team.
- ✅ Jonas Hector: Jonas Armin Hector (born 27 May 1990) is a German professional footballer who plays as a left back for Bundesliga club 1.
- ✅ Robert Lewandowski (] ; born 21 August 1988) is a Polish professional footballer who plays as a striker for Bundesliga club Bayern Munich, and captains the Poland national team.

#### Removed Sentences (Pruned by Budget/Redundancy):
- ❌ Jonas Troest: He has played 25 matches for the Danish under-21 national team.
- ❌ Jonas Troest is the older brother of footballer Magnus Troest.
- ❌ Tobias Schweinsteiger: He is the older brother of former German international and Chicago Fire player Bastian Schweinsteiger.

---

### Example 3 (ID: `hotpot_q0005231`)
- **Question**: The Curse of Rocky Colavito is one of several sports superstitions centered on the failure to win a championship in any major league sport for how many years?
- **Gold Answer**: `['52']`
- **Generated Answer**: `52 years`
- **Retrieved Passages**: Curse of Rocky Colavito, Cleveland sports curse, Cleveland sports curse, 1965 Cleveland Indians season, 1996–97 Portland Trail Blazers season

#### Gold Supporting Facts:
> 🔍 The Curse of Rocky Colavito is a sports-related curse that supposedly prevents the Cleveland Indians Major League Baseball (MLB) franchise from winning, be it the World Series, the American League (AL) pennant, reaching postseason play, or even getting into a pennant race.
> 🔍  It is one of several curses believed to have stricken the city of Cleveland's major sports franchises for decades.
> 🔍 The Cleveland sports curse was a sports superstition involving the city of Cleveland, Ohio, and its major league professional sports teams, centered on the failure to win a championship in any major league sport for a period of 52 years, from 1964 to 2016.

#### Selected EARC Sentences:
- ✅ Cleveland sports curse: The Cleveland sports curse was a sports superstition involving the city of Cleveland, Ohio, and its major league professional sports teams, centered on the failure to win a championship in any major league sport for a period of 52 years, from 1964 to 2016.
- ✅ Curse of Rocky Colavito: It is one of several curses believed to have stricken the city of Cleveland's major sports franchises for decades.
- ✅ in Major League Baseball.[4][5] The 108-year drought was also the longest such occurrence in all major North American sports.
- ✅ 1965 Cleveland Indians season: This season also marked the return of Rocky Colavito.

#### Removed Sentences (Pruned by Budget/Redundancy):
- ❌ Curse of Rocky Colavito: Its origin is traced back to the unpopular trade of right fielder Rocky Colavito to the Detroit Tigers for Harvey Kuenn in 1960.
- ❌ Cleveland sports curse: Combined with the short-lived Barons franchise of the National Hockey League (NHL), Cleveland teams endured an unprecedented 147-season championship drought, having not won a title since the Browns defeated the Baltimore Colts in the 1964 NFL Championship Game two seasons prior to the first Super Bowl.
- ❌ Curse of Rocky Colavito: It was not claimed that Colavito placed the curse, and he has denied doing so.

---

### Example 4 (ID: `hotpot_q0005094`)
- **Question**: The National Education Goals Panel discontinued their reports by the Act that reauthorized which piece of legislation?
- **Gold Answer**: `['Elementary and Secondary Education Act']`
- **Generated Answer**: `No Child Left Behind Act`
- **Retrieved Passages**: National Education Goals Panel, No Child Left Behind Act, Education Consolidation and Improvement Act, Factory Acts, Education Act 1944

#### Gold Supporting Facts:
> 🔍  The panel issued many reports between 1991 and 1999, and it was discontinued by the No Child Left Behind Act which became law in January, 2002.
> 🔍 The No Child Left Behind Act of 2001 (NCLB) was a U.S. Act of Congress that reauthorized the Elementary and Secondary Education Act; it included Title I provisions applying to disadvantaged students.

#### Selected EARC Sentences:
- ✅ National Education Goals Panel: The panel issued many reports between 1991 and 1999, and it was discontinued by the No Child Left Behind Act which became law in January, 2002.
- ✅ Education Act 1944: The Act renamed the Board of Education as the Ministry of Education, giving it greater powers and a bigger budget, ended fee-paying for state secondary schools, and enforced the division between primary (5–11 years old) and secondary (11–15 years old) that many local authorities had already introduced.
- ✅ No Child Left Behind Act The No Child Left Behind Act of 2001(NCLB)[1][2] was a U.S. Act of Congress that reauthorized the Elementary and Secondary Education Act; it included Title I provisions applying to disadvantaged students.[3]
- ✅ Elementary and Secondary Education Act: On January 23, 2017, House Bill 610 was introduced to repeal this act.

#### Removed Sentences (Pruned by Budget/Redundancy):
- ❌ National Education Goals Panel: The 1994 Goals 2000 legislation formally established the National Education Goals Panel in federal law, and the legislation assigned it annual reporting responsibilities.
- ❌ National Education Goals Panel: The organization was established to report on the nation's progress toward the six education goals adopted at the Charlottesville meeting.
- ❌ Education Act 1944: The Education Act 1944 (7 and 8 Geo 6 c. 31) made numerous major changes in the provision and governance of secondary schools in England and Wales.

---
