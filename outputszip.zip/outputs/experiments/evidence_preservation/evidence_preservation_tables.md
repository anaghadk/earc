# Experiment 4 — Evidence Preservation Tables (HotpotQA Multi-Hop)

## Table 1: Supporting-Document Recall Table
Measures the percentage of gold supporting documents retained after compression.

| Method | Supporting Document Recall (%) | Avg Context Tokens | Context Type |
| :--- | :---: | :---: | :--- |
| Standard RAG | **58.70%** | 1283.9 | Full retrieved context |
| Top-k (top 5 passages) | **52.65%** | 597.8 | Top 5 passages |
| LLMLingua-2 | **58.70%** | 296.2 | Token pruned (300t) |
| Semantic-only EARC (α=1.0, β=0.0) | **57.85%** | 294.1 | Pure similarity |
| **Full EARC (α=0.7, β=0.3)** | **57.15%** | 294.3 | **Hybrid + Redundancy** |

## Table 2: Supporting-Sentence Recall Table
Measures the percentage of gold supporting sentences retained in the compressed context.

| Method | Supporting Sentence Recall (%) | Avg Context Tokens | Method Type |
| :--- | :---: | :---: | :--- |
| Standard RAG | **57.86%** | 1283.9 | standard_rag |
| Top-k (top 5 passages) | **51.78%** | 597.8 | topk |
| LLMLingua-2 | **0.40%** | 296.2 | llmlingua2 |
| Semantic-only EARC (α=1.0, β=0.0) | **42.15%** | 294.1 | semantic_earc |
| **Full EARC (α=0.7, β=0.3)** | **40.50%** | 294.3 | full_earc |

## Table 3: Evidence Coverage Table
Measures the percentage of questions where ALL required reasoning evidence sentences are present simultaneously in the compressed context.

| Method | Evidence Coverage (%) | Avg Tokens | Multi-Hop Sufficiency |
| :--- | :---: | :---: | :--- |
| Standard RAG | **30.20%** | 1283.9 | Complete Upper Bound |
| Top-k (top 5 passages) | **22.10%** | 597.8 | Poor |
| LLMLingua-2 | **0.00%** | 296.2 | Poor |
| Semantic-only EARC (α=1.0, β=0.0) | **14.20%** | 294.1 | Poor |
| **Full EARC (α=0.7, β=0.3)** | **14.00%** | 294.3 | Poor |

## Table 4: Document Diversity Table
Measures the average number of unique source documents represented in the compressed context.

| Method | Unique Documents Represented | Cross-Doc Breadth |
| :--- | :---: | :--- |
| Standard RAG | **7.86** | All 10 retrieved docs |
| Top-k (top 5 passages) | **4.18** | Top 5 passages |
| LLMLingua-2 | **7.86** | Filtered representation |
| Semantic-only EARC (α=1.0, β=0.0) | **6.91** | Filtered representation |
| **Full EARC (α=0.7, β=0.3)** | **6.36** | Filtered representation |

## Table 5: Redundancy Table
Measures the percentage of candidate sentences eliminated by cross-document semantic deduplication.

| Method | Redundancy Removed (%) | Filtering Mechanism |
| :--- | :---: | :--- |
| Standard RAG | **0.00%** | None (uncompressed) |
| Top-k (top 5 passages) | **0.00%** | None (uncompressed) |
| LLMLingua-2 | **0.00%** | Perplexity / token classification |
| Semantic-only EARC (α=1.0, β=0.0) | **0.00%** | Disabled (A1) |
| **Full EARC (α=0.7, β=0.3)** | **5.15%** | Cosine similarity (τ=0.85) |

## Table 6: Answer Correctness (EM and F1) Table
Measures downstream question answering performance on HotpotQA with Mistral.

| Method | Exact Match (%) | Token F1 (%) | Avg Tokens | Compression Ratio |
| :--- | :---: | :---: | :---: | :---: |
| Standard RAG | **38.10%** | **46.67%** | 1283.9 | 1.00x |
| Top-k (top 5 passages) | **35.80%** | **44.53%** | 597.8 | 2.15x |
| LLMLingua-2 | **28.10%** | **38.19%** | 296.2 | 4.33x |
| Semantic-only EARC (α=1.0, β=0.0) | **0.00%** | **0.00%** | 294.1 | 4.37x |
| **Full EARC (α=0.7, β=0.3)** | **36.70%** | **44.94%** | 294.3 | 4.36x |
