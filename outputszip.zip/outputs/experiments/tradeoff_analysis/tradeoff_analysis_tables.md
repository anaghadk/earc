# Experiment 7 — Compression–Quality–Cost Trade-off Analysis Report

## 1. Executive Summary & Evaluation Dimensions
This experiment evaluates the multi-dimensional efficiency trade-offs between:
1. **Context Size**: Average prompt tokens fed into the LLM.
2. **Compression Ratio**: Factor of context reduction ($T_{\text{orig}} / T_{\text{compressed}}$).
3. **Answer Quality**: Exact Match (EM) and Token F1.
4. **Compression Overhead**: Execution latency added by candidate decomposition, scoring, and filtering.
5. **End-to-End Latency**: Total pipeline time (Retrieval + Compression + Generation).

### Clearly Defined Derived Efficiency Measures
- **F1 per 1,000 Input Tokens**: $\text{F1} / (\text{Tokens} / 1000)$ — Measures factual information density per unit prompt cost.
- **EM per 1,000 Input Tokens**: $\text{EM} / (\text{Tokens} / 1000)$ — Measures exact-match return on token spend.
- **Token Reduction per Second of Overhead**: $(\text{Orig Tokens} - \text{Comp Tokens}) / \text{Compression Latency (s)}$ — Measures the throughput of context pruning.

## 2. Comprehensive Trade-off Tables
### Provider / Model: `Ministral-8B`

| Dataset | Method | Orig Tokens | Comp Tokens | Comp % | Comp Ratio | EM (%) | F1 (%) | Comp Time (s) | Gen Time (s) | E2E Latency (s) | F1 / 1k Tokens | EM / 1k Tokens | Tokens Saved / Overhead Sec |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| HOTPOT | Standard RAG | 1284.4 | 1284.4 | 0.0% | 1.00x | **38.10%** | **46.67%** | 0.000s (None) | 0.786s | 0.943s | **36.3** | **29.7** | N/A |
| HOTPOT | Top-k (top 5) | 1284.4 | 598.1 | 53.4% | 2.15x | **35.80%** | **44.53%** | 0.000s (None) | 0.746s | 0.903s | **74.5** | **59.9** | N/A |
| HOTPOT | LLMLingua-2 (300t) | 1284.4 | 296.2 | 75.0% | 4.35x | **28.10%** | **38.19%** | 0.188s | 0.715s | 1.060s | **128.9** | **94.9** | 5,245.2 t/s |
| HOTPOT | **EARC (300t)** | 1208.2 | 294.4 | 73.2% | 4.10x | **36.70%** | **44.94%** | 0.378s | 0.770s | 1.304s | **152.7** | **124.7** | 2,420.7 t/s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| NQ | Standard RAG | 1497.2 | 1497.2 | 0.0% | 1.00x | **26.90%** | **38.81%** | 0.000s (None) | 0.851s | 1.014s | **25.9** | **18.0** | N/A |
| NQ | Top-k (top 5) | 1497.2 | 726.6 | 51.5% | 2.06x | **25.20%** | **36.36%** | 0.000s (None) | 0.783s | 0.945s | **50.0** | **34.7** | N/A |
| NQ | LLMLingua-2 (300t) | 1497.2 | 302.4 | 79.0% | 4.97x | **21.00%** | **31.74%** | 0.271s | 0.676s | 1.110s | **105.0** | **69.4** | 4,412.1 t/s |
| NQ | **EARC (300t)** | 1427.3 | 295.4 | 78.2% | 4.83x | **23.30%** | **33.84%** | 0.431s | 0.723s | 1.317s | **114.6** | **78.9** | 2,623.2 t/s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| TRIVIA | Standard RAG | 1695.5 | 1695.5 | 0.0% | 1.00x | **56.10%** | **66.57%** | 0.000s (None) | 0.709s | 0.867s | **39.3** | **33.1** | N/A |
| TRIVIA | Top-k (top 5) | 1695.5 | 842.8 | 50.3% | 2.01x | **54.10%** | **64.42%** | 0.000s (None) | 0.683s | 0.842s | **76.4** | **64.2** | N/A |
| TRIVIA | LLMLingua-2 (300t) | 1695.5 | 304.4 | 81.5% | 5.61x | **49.80%** | **60.01%** | 0.173s | 0.674s | 1.005s | **197.1** | **163.6** | 8,041.0 t/s |
| TRIVIA | **EARC (300t)** | 1624.2 | 295.2 | 81.2% | 5.50x | **52.30%** | **62.47%** | 0.489s | 0.691s | 1.339s | **211.6** | **177.2** | 2,715.0 t/s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

### Provider / Model: `Llama 3.2`

| Dataset | Method | Orig Tokens | Comp Tokens | Comp % | Comp Ratio | EM (%) | F1 (%) | Comp Time (s) | Gen Time (s) | E2E Latency (s) | F1 / 1k Tokens | EM / 1k Tokens | Tokens Saved / Overhead Sec |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| HOTPOT | Standard RAG | 1284.4 | 1284.4 | 0.0% | 1.00x | **22.90%** | **29.32%** | 0.000s (None) | 2.371s | 2.527s | **22.8** | **17.8** | N/A |
| HOTPOT | Top-k (top 5) | 1284.4 | 598.1 | 53.4% | 2.15x | **24.10%** | **30.69%** | 0.000s (None) | 2.199s | 2.356s | **51.3** | **40.3** | N/A |
| HOTPOT | LLMLingua-2 (300t) | 1284.4 | 296.2 | 75.0% | 4.35x | **22.40%** | **28.76%** | 0.188s | 2.250s | 2.595s | **97.1** | **75.6** | 5,245.2 t/s |
| HOTPOT | **EARC (300t)** | 1208.2 | 294.4 | 73.2% | 4.10x | **28.40%** | **34.68%** | 0.378s | 2.232s | 2.766s | **117.8** | **96.5** | 2,420.7 t/s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| NQ | Standard RAG | 1497.2 | 1497.2 | 0.0% | 1.00x | **24.40%** | **32.81%** | 0.000s (None) | 2.446s | 2.609s | **21.9** | **16.3** | N/A |
| NQ | Top-k (top 5) | 1497.2 | 726.6 | 51.5% | 2.06x | **23.70%** | **31.96%** | 0.000s (None) | 2.231s | 2.393s | **44.0** | **32.6** | N/A |
| NQ | LLMLingua-2 (300t) | 1497.2 | 302.4 | 79.0% | 4.97x | **18.40%** | **25.88%** | 0.271s | 2.307s | 2.740s | **85.6** | **60.9** | 4,412.1 t/s |
| NQ | **EARC (300t)** | 1427.3 | 295.4 | 78.2% | 4.83x | **21.30%** | **29.16%** | 0.431s | 2.289s | 2.883s | **98.7** | **72.1** | 2,623.2 t/s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| TRIVIA | Standard RAG | 1695.5 | 1695.5 | 0.0% | 1.00x | **40.30%** | **48.50%** | 0.000s (None) | 2.349s | 2.507s | **28.6** | **23.8** | N/A |
| TRIVIA | Top-k (top 5) | 1695.5 | 842.8 | 50.3% | 2.01x | **40.40%** | **48.56%** | 0.000s (None) | 2.162s | 2.320s | **57.6** | **47.9** | N/A |
| TRIVIA | LLMLingua-2 (300t) | 1695.5 | 304.4 | 81.5% | 5.61x | **37.80%** | **46.00%** | 0.173s | 2.195s | 2.526s | **151.1** | **124.2** | 8,041.0 t/s |
| TRIVIA | **EARC (300t)** | 1624.2 | 295.2 | 81.2% | 5.50x | **44.60%** | **52.52%** | 0.489s | 2.177s | 2.824s | **177.9** | **151.1** | 2,715.0 t/s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
