# Experiment 6 — Statistical Validation of EARC Evaluation Results

## 1. Executive Summary & Methodology
- **Resampling Procedure**: Paired bootstrap resampling at the **question level** with **5,000 resamples**.
- **Evaluation Scale**: 1,000 matched examples per dataset (`seed=42`).
- **Difference Metric**: $\Delta = \text{EARC} - \text{Baseline}$.
- **Significance Threshold**: Two-sided $\alpha = 0.05$. A difference is declared statistically significant if and only if the **95% Bootstrap Confidence Interval strictly excludes zero** ($p < 0.05$).

## 2. Statistical Comparison Tables
### Configuration: `NQ + Llama 3.2`

| Metric | Comparison | EARC Mean (%) | Baseline Mean (%) | Absolute Difference (Δ) | 95% Bootstrap CI | Contains Zero? | Statistically Significant? |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **EM** | EARC vs. Standard RAG | 21.30% | 24.40% | **-3.10%** | [-5.20%, -1.10%] | No | **Yes (p < 0.05)** |
| **F1** | EARC vs. Standard RAG | 29.16% | 32.81% | **-3.66%** | [-5.80%, -1.56%] | No | **Yes (p < 0.05)** |
| **EM** | EARC vs. Top-k | 21.30% | 23.70% | **-2.40%** | [-4.50%, -0.30%] | No | **Yes (p < 0.05)** |
| **F1** | EARC vs. Top-k | 29.16% | 31.96% | **-2.81%** | [-4.85%, -0.76%] | No | **Yes (p < 0.05)** |
| **EM** | EARC vs. LLMLingua-2 | 21.30% | 18.40% | **+2.90%** | [+0.60%, +5.20%] | No | **Yes (p < 0.05)** |
| **F1** | EARC vs. LLMLingua-2 | 29.16% | 25.88% | **+3.28%** | [+0.99%, +5.64%] | No | **Yes (p < 0.05)** |

### Configuration: `NQ + Ministral-8B`

| Metric | Comparison | EARC Mean (%) | Baseline Mean (%) | Absolute Difference (Δ) | 95% Bootstrap CI | Contains Zero? | Statistically Significant? |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **EM** | EARC vs. Standard RAG | 23.30% | 26.90% | **-3.60%** | [-5.50%, -1.70%] | No | **Yes (p < 0.05)** |
| **F1** | EARC vs. Standard RAG | 33.84% | 38.81% | **-4.97%** | [-6.83%, -3.11%] | No | **Yes (p < 0.05)** |
| **EM** | EARC vs. Top-k | 23.30% | 25.20% | **-1.90%** | [-3.80%, +0.10%] | Yes | No (p ≥ 0.05) |
| **F1** | EARC vs. Top-k | 33.84% | 36.36% | **-2.52%** | [-4.38%, -0.67%] | No | **Yes (p < 0.05)** |
| **EM** | EARC vs. LLMLingua-2 | 23.30% | 21.00% | **+2.30%** | [-0.20%, +4.80%] | Yes | No (p ≥ 0.05) |
| **F1** | EARC vs. LLMLingua-2 | 33.84% | 31.74% | **+2.10%** | [-0.25%, +4.49%] | Yes | No (p ≥ 0.05) |

### Configuration: `HotpotQA + Llama 3.2`

| Metric | Comparison | EARC Mean (%) | Baseline Mean (%) | Absolute Difference (Δ) | 95% Bootstrap CI | Contains Zero? | Statistically Significant? |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **EM** | EARC vs. Standard RAG | 28.40% | 22.90% | **+5.50%** | [+3.30%, +7.60%] | No | **Yes (p < 0.05)** |
| **F1** | EARC vs. Standard RAG | 34.68% | 29.32% | **+5.36%** | [+3.12%, +7.57%] | No | **Yes (p < 0.05)** |
| **EM** | EARC vs. Top-k | 28.40% | 24.10% | **+4.30%** | [+2.20%, +6.40%] | No | **Yes (p < 0.05)** |
| **F1** | EARC vs. Top-k | 34.68% | 30.69% | **+3.99%** | [+1.85%, +6.09%] | No | **Yes (p < 0.05)** |
| **EM** | EARC vs. LLMLingua-2 | 28.40% | 22.40% | **+6.00%** | [+3.50%, +8.50%] | No | **Yes (p < 0.05)** |
| **F1** | EARC vs. LLMLingua-2 | 34.68% | 28.76% | **+5.92%** | [+3.49%, +8.32%] | No | **Yes (p < 0.05)** |

### Configuration: `HotpotQA + Ministral-8B`

| Metric | Comparison | EARC Mean (%) | Baseline Mean (%) | Absolute Difference (Δ) | 95% Bootstrap CI | Contains Zero? | Statistically Significant? |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **EM** | EARC vs. Standard RAG | 36.70% | 38.10% | **-1.40%** | [-3.40%, +0.70%] | Yes | No (p ≥ 0.05) |
| **F1** | EARC vs. Standard RAG | 44.94% | 46.67% | **-1.73%** | [-3.61%, +0.20%] | Yes | No (p ≥ 0.05) |
| **EM** | EARC vs. Top-k | 36.70% | 35.80% | **+0.90%** | [-1.10%, +2.80%] | Yes | No (p ≥ 0.05) |
| **F1** | EARC vs. Top-k | 44.94% | 44.53% | **+0.40%** | [-1.53%, +2.32%] | Yes | No (p ≥ 0.05) |
| **EM** | EARC vs. LLMLingua-2 | 36.70% | 28.10% | **+8.60%** | [+6.10%, +11.10%] | No | **Yes (p < 0.05)** |
| **F1** | EARC vs. LLMLingua-2 | 44.94% | 38.19% | **+6.74%** | [+4.44%, +9.07%] | No | **Yes (p < 0.05)** |

### Configuration: `TriviaQA + Llama 3.2`

| Metric | Comparison | EARC Mean (%) | Baseline Mean (%) | Absolute Difference (Δ) | 95% Bootstrap CI | Contains Zero? | Statistically Significant? |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **EM** | EARC vs. Standard RAG | 44.60% | 40.30% | **+4.30%** | [+1.80%, +6.90%] | No | **Yes (p < 0.05)** |
| **F1** | EARC vs. Standard RAG | 52.52% | 48.50% | **+4.02%** | [+1.54%, +6.54%] | No | **Yes (p < 0.05)** |
| **EM** | EARC vs. Top-k | 44.60% | 40.40% | **+4.20%** | [+1.60%, +6.80%] | No | **Yes (p < 0.05)** |
| **F1** | EARC vs. Top-k | 52.52% | 48.56% | **+3.96%** | [+1.52%, +6.41%] | No | **Yes (p < 0.05)** |
| **EM** | EARC vs. LLMLingua-2 | 44.60% | 37.80% | **+6.80%** | [+3.80%, +9.70%] | No | **Yes (p < 0.05)** |
| **F1** | EARC vs. LLMLingua-2 | 52.52% | 46.00% | **+6.53%** | [+3.80%, +9.35%] | No | **Yes (p < 0.05)** |

### Configuration: `TriviaQA + Ministral-8B`

| Metric | Comparison | EARC Mean (%) | Baseline Mean (%) | Absolute Difference (Δ) | 95% Bootstrap CI | Contains Zero? | Statistically Significant? |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **EM** | EARC vs. Standard RAG | 52.30% | 56.10% | **-3.80%** | [-6.00%, -1.60%] | No | **Yes (p < 0.05)** |
| **F1** | EARC vs. Standard RAG | 62.47% | 66.57% | **-4.09%** | [-6.10%, -2.10%] | No | **Yes (p < 0.05)** |
| **EM** | EARC vs. Top-k | 52.30% | 54.10% | **-1.80%** | [-4.00%, +0.50%] | Yes | No (p ≥ 0.05) |
| **F1** | EARC vs. Top-k | 62.47% | 64.42% | **-1.95%** | [-4.04%, +0.10%] | Yes | No (p ≥ 0.05) |
| **EM** | EARC vs. LLMLingua-2 | 52.30% | 49.80% | **+2.50%** | [-0.60%, +5.50%] | Yes | No (p ≥ 0.05) |
| **F1** | EARC vs. LLMLingua-2 | 62.47% | 60.01% | **+2.47%** | [-0.11%, +5.03%] | Yes | No (p ≥ 0.05) |
